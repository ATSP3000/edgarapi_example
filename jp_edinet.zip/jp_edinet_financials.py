#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# jp_edinet_financials.py - Japanese listed-firm financials from EDINET (FSA)
#
# SETUP
#   pip install requests tqdm truststore
#   (tqdm = progress bar, truststore = works behind antivirus/company HTTPS
#    inspection; both optional)
#
# GETTING A FREE EDINET API KEY (one time, ~5 minutes)
#   1. Open https://api.edinet-fsa.go.jp/api/auth/index.aspx?mode=1
#      (the "API key issuance" page; it is linked from the EDINET API
#      documentation). Allow pop-ups for the site - the sign-up opens in one.
#   2. Sign up with an email address, enter the code EDINET emails you, and set
#      a password. You will also be asked for a phone number for a verification
#      code (multi-factor login).
#   3. Fill in the contact form (name, phone). The key (32 characters) is shown
#      on the next screen. It does not expire; if you lose it, sign in to the
#      same page and look it up again.
#   4. Keep the key out of your scripts and command history: set it once per
#      terminal as an environment variable
#        Windows (cmd):         set EDINET_KEY=your_key
#        Windows (PowerShell):  $env:EDINET_KEY="your_key"
#        macOS/Linux:           export EDINET_KEY=your_key
#
# HOW TO RUN
#   python jp_edinet_financials.py --start-year 2025 --end-year 2025
#
#   # quick test (~2 minutes): one week of the June filing peak, first 25 filings
#   python jp_edinet_financials.py --scan-from 2026-06-22 --scan-to 2026-06-28 --limit 25
#
#   # only the labor panel (reuses the files already downloaded)
#   python jp_edinet_financials.py --start-year 2025 --end-year 2025 --labor-only
#
# HOW IT WORKS
#   1. Frame: EDINET's code list (Edinetcode.zip, no key needed) lists every
#      filer. Kept: domestic companies currently flagged as listed (~3,900).
#      Delisted firms are not in the frame.
#   2. Scan: EDINET has no "filings for company X" query - only "everything
#      filed on date D". The script asks for every date that can hold a filing
#      for the requested fiscal years (FY2025: 2025-06-01 to today, ~500 calls)
#      and keeps annual securities reports (有価証券報告書, docTypeCode 120).
#   3. Download: one ZIP per filing - EDINET's own CSV conversion of the XBRL
#      (type=5), ~3,900 calls for FY2025. Every ZIP is kept in edinet_raw/docs/
#      and never downloaded twice, so the raw filings are on disk for later
#      work and an interrupted run resumes where it stopped.
#   4. Parse: every output below comes from those ZIPs - no extra calls.
#   Expect ~2-3 hours for a full FY2025 run at the default pace, ~1-2 GB disk.
#
# OUTPUT
#   frame_jp.csv          the sample: every listed firm in EDINET's code list
#   filings_jp.csv        which filing was used per firm-year, or why none was
#   panel_jp.csv          the same 11 harmonized variables as the US/KR/TW/UK
#                         panels, full yen
#   panel_v2_jp.csv       Panel V2 - the same 21 columns as sec_panel_v2.py,
#                         mapped to the nearest Japanese element ("NA" if none)
#   coverage_v2_jp.csv    which Japanese elements feed each V2 column, coverage,
#                         and where the mapping is only approximate
#   panel_labor_jp.csv    the shared labor columns (KR/TW) plus Japan-only ones
#   wide_jp.csv           one row per firm-year: every standard line item
#                         reported by >= 1% of firm-years (--wide-min-share)
#   long_jp.csv           every current-year fact of every filing (segments,
#                         parent-only figures, notes), text blocks excluded
#   dictionary_jp.csv     every wide column: English name, element ID, Japanese
#                         label, how many firm-years report it
#
# FISCAL YEAR
#   Same rule as the other scripts (Compustat): a year ending Jan-May belongs
#   to the previous fiscal year. A March year-end firm's FY2025 is April 2025 -
#   March 2026, which is also what Japanese firms call 2025年度. Those reports
#   were filed in late June 2026.
#
# CONSOLIDATION
#   Consolidated figures for firms that prepare consolidated statements. Firms
#   without subsidiaries publish parent-only statements, which ARE the whole
#   firm; they are kept and tagged "separate_no_cfs" (as in the Korea panel).
#   Parent-only figures of consolidated groups are never mixed in; they are in
#   long_jp.csv (scope = parent).
#
# ACCOUNTING STANDARDS
#   Japan GAAP (~95% of firms) and IFRS (~280 large firms) have full statement
#   tagging. The handful of US GAAP / JMIS filers tag only the five-year
#   summary (revenue, profit, assets, equity, cash), so COGS, capex etc. are
#   blank for them. accounting_standard says which applies.
#
# FINANCIAL FIRMS
#   Banks and insurers have no sales/COGS. total_revenue picks up 経常収益
#   (ordinary revenue) from the summary; cogs/gross_profit stay blank. Filter
#   on isic_section == "K" before pooling with industrial firms.
#
# PACE
#   EDINET publishes no rate limit, but it drops connections when hit too fast.
#   The script waits RATE_LIMIT seconds between calls and slows down on its own
#   when connections drop. If you still see repeated drops, use --rate-limit 3.
# -----------------------------------------------------------------------------

import argparse, csv, datetime as dt, io, json, logging, os, re, sys, threading, time
import unicodedata, zipfile
from collections import Counter, defaultdict

import requests

try:                     # use the operating system's certificate store if available,
    import truststore    # so corporate TLS inspection (antivirus, proxy) just works
    truststore.inject_into_ssl()
except ImportError:
    truststore = None

try:
    from tqdm import tqdm
except ImportError:                       # tqdm is optional
    def tqdm(it, **_):
        return it

# ============================ ADJUST THESE ===================================
RATE_LIMIT = 1.5                 # seconds between calls to EDINET
MAX_RATE_LIMIT = 15.0            # slow-down ceiling after dropped connections
RAW_DIR = "edinet_raw"           # code list, daily lists and every filing ZIP
LIST_FINAL_AFTER_DAYS = 14       # daily lists older than this are cached for good
CODELIST_MAX_AGE_DAYS = 7        # re-download the code list after this many days
HEARTBEAT_SECONDS = 20           # plain-text status line at least this often
STALL_WARN_SECONDS = 30          # warn if one call hangs this long
SHOW_BAR = True                  # tqdm bars; --no-bar turns them off
WIDE_MIN_SHARE = 0.01            # wide_jp.csv keeps items reported by >= 1%
NA = "NA"                        # written where a value is not reported
# =============================================================================

API = "https://api.edinet-fsa.go.jp/api/v2"
CODELIST_URL = ("https://disclosure2dl.edinet-fsa.go.jp/searchdocument/"
                "codelist/Edinetcode.zip")
ANNUAL_REPORT = "120"            # 有価証券報告書; 130 = its amendment
AMENDMENT = "130"
STD_PREFIXES = {"jppfs_cor", "jpigp_cor", "jpcrp_cor", "jpdei_cor"}
TAXONOMY = {"jppfs_cor": "Japan GAAP statements", "jpigp_cor": "IFRS statements",
            "jpcrp_cor": "annual report body", "jpdei_cor": "document info"}
CUR_DUR, CUR_INST, FILING = "CurrentYearDuration", "CurrentYearInstant", "FilingDateInstant"

log = logging.getLogger("edinet")

# ----------------------------------------------------------------------------
# TSE 33-industry classification (EDINET's 提出者業種) -> English, ISIC section
# ----------------------------------------------------------------------------
TSE33 = {
    "水産・農林業": ("Fishery, Agriculture & Forestry", "A"), "鉱業": ("Mining", "B"),
    "建設業": ("Construction", "F"), "食料品": ("Foods", "C"),
    "繊維製品": ("Textiles & Apparels", "C"), "パルプ・紙": ("Pulp & Paper", "C"),
    "化学": ("Chemicals", "C"), "医薬品": ("Pharmaceutical", "C"),
    "石油・石炭製品": ("Oil & Coal Products", "C"), "ゴム製品": ("Rubber Products", "C"),
    "ガラス・土石製品": ("Glass & Ceramics Products", "C"), "鉄鋼": ("Iron & Steel", "C"),
    "非鉄金属": ("Nonferrous Metals", "C"), "金属製品": ("Metal Products", "C"),
    "機械": ("Machinery", "C"), "電気機器": ("Electric Appliances", "C"),
    "輸送用機器": ("Transportation Equipment", "C"),
    "精密機器": ("Precision Instruments", "C"), "その他製品": ("Other Products", "C"),
    "電気・ガス業": ("Electric Power & Gas", "D"), "陸運業": ("Land Transportation", "H"),
    "海運業": ("Marine Transportation", "H"), "空運業": ("Air Transportation", "H"),
    "倉庫・運輸関連業": ("Warehousing & Harbor Transportation", "H"),
    "情報・通信業": ("Information & Communication", "J"), "卸売業": ("Wholesale Trade", "G"),
    "小売業": ("Retail Trade", "G"), "銀行業": ("Banks", "K"),
    "証券、商品先物取引業": ("Securities & Commodity Futures", "K"),
    "保険業": ("Insurance", "K"), "その他金融業": ("Other Financing Business", "K"),
    "不動産業": ("Real Estate", "L"), "サービス業": ("Services", "N"),
}
_TSE33_KEY = {re.sub(r"[\s・、,，]", "", unicodedata.normalize("NFKC", k)): v
              for k, v in TSE33.items()}


def industry(name):
    key = re.sub(r"[\s・、,，]", "", unicodedata.normalize("NFKC", str(name or "")))
    return _TSE33_KEY.get(key, ("", "?"))


# ----------------------------------------------------------------------------
# Core panel: element ladders (local names; first hit wins)
# Statement elements first, then the five-year summary (経営指標等), which every
# filer tags whatever its standard, then - last - the Japanese caption.
# ----------------------------------------------------------------------------
VARS = ["total_revenue", "cogs", "gross_profit", "operating_income", "net_income",
        "total_assets", "total_liabilities", "shareholders_equity",
        "cash_and_equivalents", "capex", "rd_expense"]
DURATION_VARS = {"total_revenue", "cogs", "gross_profit", "operating_income",
                 "net_income", "capex", "rd_expense"}
LADDER = {
    "total_revenue": ["NetSales", "Revenue", "RevenueIFRS", "NetSalesIFRS", "Revenue2IFRS",
                      "OperatingRevenue1", "OperatingRevenue2",
                      "NetSalesOfCompletedConstructionContracts",
                      "NetSalesSummaryOfBusinessResults", "RevenueIFRSSummaryOfBusinessResults",
                      "RevenuesUSGAAPSummaryOfBusinessResults",
                      "RevenueJMISSummaryOfBusinessResults",
                      "OperatingRevenue1SummaryOfBusinessResults",
                      "OperatingRevenue2SummaryOfBusinessResults",
                      "GrossOperatingRevenueSummaryOfBusinessResults",
                      "OrdinaryIncomeSummaryOfBusinessResults"],   # banks: 経常収益
    "cogs": ["CostOfSales", "CostOfSalesIFRS", "CostOfSalesOfCompletedConstructionContracts"],
    "gross_profit": ["GrossProfit", "GrossProfitIFRS",
                     "GrossProfitOnCompletedConstructionContracts"],
    "operating_income": ["OperatingIncome", "OperatingProfitLossIFRS",
                         "OperatingIncomeLossUSGAAPSummaryOfBusinessResults",
                         "OperatingProfitLossIFRSSummaryOfBusinessResults"],
    "net_income": ["ProfitLoss", "ProfitLossIFRS", "NetIncome", "NetIncomeLoss",
                   "ProfitLossAttributableToOwnersOfParent",
                   "ProfitLossAttributableToOwnersOfParentIFRS",
                   "NetIncomeLossSummaryOfBusinessResults",
                   "ProfitLossIFRSSummaryOfBusinessResults",
                   "ProfitLossJMISSummaryOfBusinessResults",
                   "ProfitLossAttributableToOwnersOfParentSummaryOfBusinessResults",
                   "ProfitLossAttributableToOwnersOfParentIFRSSummaryOfBusinessResults",
                   "NetIncomeLossAttributableToOwnersOfParentUSGAAPSummaryOfBusinessResults"],
    "total_assets": ["Assets", "AssetsIFRS", "TotalAssetsSummaryOfBusinessResults",
                     "TotalAssetsIFRSSummaryOfBusinessResults",
                     "TotalAssetsUSGAAPSummaryOfBusinessResults",
                     "TotalAssetsJMISSummaryOfBusinessResults"],
    "total_liabilities": ["Liabilities", "LiabilitiesIFRS"],
    # NetAssets (純資産) includes non-controlling interests, so A = L + E holds
    "shareholders_equity": ["NetAssets", "EquityIFRS", "NetAssetsSummaryOfBusinessResults",
                            "TotalEquityIFRSSummaryOfBusinessResults",
                            "EquityAttributableToOwnersOfParentIFRS",
                            "EquityAttributableToOwnersOfParentIFRSSummaryOfBusinessResults",
                            "EquityAttributableToOwnersOfParentUSGAAPSummaryOfBusinessResults"],
    # CashAndDeposits (現金及び預金) is the balance-sheet line and includes
    # time deposits, so it is the last resort
    "cash_and_equivalents": ["CashAndCashEquivalents", "CashAndCashEquivalentsIFRS",
                             "CashAndCashEquivalentsSummaryOfBusinessResults",
                             "CashAndCashEquivalentsIFRSSummaryOfBusinessResults",
                             "CashAndCashEquivalentsUSGAAPSummaryOfBusinessResults",
                             "CashAndDeposits"],
    "capex": ["PurchaseOfPropertyPlantAndEquipmentInvCF",
              "PurchaseOfPropertyPlantAndEquipmentInvCFIFRS",
              "PurchaseOfPropertyPlantAndEquipmentAndIntangibleAssetsInvCF",
              "PurchaseOfPropertyPlantAndEquipmentAndIntangibleAssetsInvCFIFRS",
              "PurchaseOfNoncurrentAssetsInvCF"],
    # R&D: the total from the 研究開発活動 section first, then the notes, then
    # the SG&A line (which misses R&D booked in manufacturing cost)
    "rd_expense": ["ResearchAndDevelopmentExpensesResearchAndDevelopmentActivities",
                   "ResearchAndDevelopmentExpensesIncludedInGeneralAndAdministrative"
                   "ExpensesAndManufacturingCostForCurrentPeriod",
                   "ResearchAndDevelopmentExpensesSGA",
                   "ResearchAndDevelopmentExpensesSGAIFRS"],
}
ABS_VARS = {"capex"}             # cash outflows are filed as negatives
# Caption fallback (項目名, NFKC-normalized, matched at the start). A caption
# containing a deny word is never used for that variable.
CAPTION = {
    "total_revenue": (r"^(売上高|売上収益|営業収益|営業収入|完成工事高|経常収益|収益)",
                      r"原価|利益|費用|総利益|損失|その他|外"),
    "cogs": (r"^(売上原価|営業原価|完成工事原価)", r"利益|明細"),
    "gross_profit": (r"^(売上総利益|完成工事総利益)", r"率"),
    "operating_income": (r"^営業利益", r"外|率"),
    "net_income": (r"^(当期純利益|親会社株主に帰属する当期純利益)", r"率|一株|1株|包括"),
    "total_assets": (r"^(資産合計|総資産額|資産の部合計)", r"率"),
    "total_liabilities": (r"^負債合計", r"率"),
    "shareholders_equity": (r"^(純資産合計|資本合計|純資産額)", r"率|一株|1株"),
}
FIELDS = ["country", "exchange", "native_id", "stock_code", "isin", "company_name",
          "company_name_local", "fiscal_year", "period_start", "period_end",
          "period_months", "consolidation_basis", "accounting_standard", "currency",
          "unit_scale", "listing_status", "native_industry_code", "industry_en",
          "isic_section", *VARS, "identity_check", "missing_fields", "sources",
          "doc_id", "filing_date"]

# ----------------------------------------------------------------------------
# Panel V2: the 21 sec_panel_v2.py columns, mapped to Japanese elements
#   elements  exact equivalents, tried in order
#   proxy     approximate stand-ins, used if no exact element; listed per row in
#             proxies_used so they can be dropped
#   sign      -1 where Japan files the opposite sign of us-gaap
# ----------------------------------------------------------------------------
V2_FIELDS = [
    {"col": "RevenueFromContractWithCustomerExcludingAssessedTax", "kind": "duration",
     "elements": LADDER["total_revenue"][:-1]},          # all but banks' 経常収益
    {"col": "GrossProfit", "kind": "duration", "elements": LADDER["gross_profit"]},
    {"col": "CostOfGoodsAndServicesSold", "kind": "duration", "elements": LADDER["cogs"]},
    {"col": "OperatingExpenses", "kind": "duration",
     "elements": ["OperatingExpenses", "OperatingExpensesIFRS"],
     "proxy": ["SellingGeneralAndAdministrativeExpenses",
               "SellingGeneralAndAdministrativeExpensesIFRS"],
     "note": "Japanese income statements have no operating-expenses total below gross "
             "profit; proxy is SG&A. OperatingExpenses (営業費用) itself is used by "
             "utilities/railways and includes cost of operations"},
    {"col": "IncreaseDecreaseInInventories", "kind": "duration", "sign": -1,
     "elements": ["DecreaseIncreaseInInventoriesOpeCF", "DecreaseIncreaseInInventoriesOpeCFIFRS",
                  "DecreaseIncreaseInInventoriesOpeCFIFRSRevised"],
     "note": "Japan files 'decrease (increase)'; sign flipped to the us-gaap convention "
             "(positive = inventories went up)"},
    {"col": "InventoryWorkInProcess", "kind": "instant",
     "elements": ["WorkInProcess", "WorkInProcessCAIFRS"],
     "proxy": ["CostsOnUncompletedConstructionContracts"],
     "note": "proxy is construction-in-progress costs (未成工事支出金) for contractors"},
    {"col": "InventoryFinishedGoods", "kind": "instant",
     "elements": ["FinishedGoods", "MerchandiseAndFinishedGoods", "FinishedGoodsCAIFRS"],
     "note": "most Japanese balance sheets report merchandise AND finished goods "
             "(商品及び製品) as one line"},
    {"col": "EmployeeRelatedLiabilitiesCurrent", "kind": "instant",
     "elements": [], "proxy": ["ProvisionForBonuses", "AccruedBonusesCLIFRS",
                               "EmployeeBenefitsAccruedCLIFRS"],
     "note": "no single Japanese element; proxy is the bonus provision (賞与引当金), "
             "the main current employee liability"},
    {"col": "InventoryRawMaterials", "kind": "instant",
     "elements": ["RawMaterials", "RawMaterialsAndSupplies", "RawMaterialsCAIFRS"],
     "note": "usually filed as raw materials AND supplies (原材料及び貯蔵品)"},
    {"col": "CostOfGoodsAndServiceExcludingDepreciationDepletionAndAmortization",
     "kind": "duration", "elements": [],
     "note": "no Japanese equivalent - cost of sales is not split ex-depreciation"},
    {"col": "CostOfGoodsAndServicesSoldDepreciation", "kind": "duration", "elements": [],
     "note": "no consolidated equivalent; depreciation in cost of sales appears only in "
             "the parent's manufacturing cost statement, which many firms omit"},
    {"col": "SellingGeneralAndAdministrativeExpense", "kind": "duration",
     "elements": ["SellingGeneralAndAdministrativeExpenses",
                  "SellingGeneralAndAdministrativeExpensesIFRS"]},
    {"col": "PropertyPlantAndEquipmentGross", "kind": "instant", "elements": [],
     "derive": "ppe_gross",
     "note": "derived: net PP&E + accumulated depreciation (Japan GAAP balance sheets "
             "that show assets gross); NA when only net amounts are shown"},
    {"col": "PropertyPlantAndEquipmentNet", "kind": "instant",
     "elements": ["PropertyPlantAndEquipment", "PropertyPlantAndEquipmentIFRS"]},
    {"col": "AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment",
     "kind": "instant", "elements": [], "derive": "acc_dep",
     "note": "one total line if filed, else the sum of the per-class accumulated "
             "depreciation lines on the balance sheet"},
    {"col": "PaymentsToAcquirePropertyPlantAndEquipment", "kind": "duration", "abs": True,
     "elements": ["PurchaseOfPropertyPlantAndEquipmentInvCF",
                  "PurchaseOfPropertyPlantAndEquipmentInvCFIFRS"],
     "proxy": ["PurchaseOfPropertyPlantAndEquipmentAndIntangibleAssetsInvCF",
               "PurchaseOfPropertyPlantAndEquipmentAndIntangibleAssetsInvCFIFRS",
               "PurchaseOfNoncurrentAssetsInvCF"],
     "note": "proxy includes intangible assets"},
    {"col": "CapitalLeasedAssetsGross", "kind": "instant",
     "elements": ["LeasedAssets"], "proxy": ["LeasedAssetsNet", "RightOfUseAssetsIFRS"],
     "note": "LeasedAssets (リース資産) is gross; proxies are net or IFRS 16 "
             "right-of-use assets (all leases, not just finance leases)"},
    {"col": "ProceedsFromSaleOfPropertyPlantAndEquipment", "kind": "duration",
     "abs": True,
     "elements": ["ProceedsFromSalesOfPropertyPlantAndEquipmentInvCF",
                  "ProceedsFromSaleOfPropertyPlantAndEquipmentInvCFIFRS"],
     "proxy": ["ProceedsFromSalesOfNoncurrentAssetsInvCF"]},
    {"col": "MachineryAndEquipmentGross", "kind": "instant",
     "elements": ["MachineryEquipmentAndVehicles", "MachineryAndEquipment"],
     "proxy": ["MachineryEquipmentAndVehiclesNet", "MachineryAndEquipmentNet"],
     "note": "consolidated line includes vehicles (機械装置及び運搬具); proxy is net "
             "when the balance sheet shows net amounts only"},
    {"col": "Land", "kind": "instant", "elements": ["Land"],
     "note": "Japan GAAP balance-sheet line; IFRS filers show land only in notes"},
    {"col": "TotalEmployees", "kind": "instant", "elements": ["NumberOfEmployees"],
     "note": "headcount at year end (consolidated group if the firm consolidates)"},
]
V2_META = ["native_id", "stock_code", "company_name", "fiscal_year", "period_end",
           "filing_date", "accounting_standard", "consolidation_basis", "industry_en",
           "isic_section", "doc_id"]
V2_TAIL = ["fields_found", "proxies_used", "elements_used"]

# ----------------------------------------------------------------------------
# Labor panel: the shared KR/TW columns, then Japan-only ones
# Salary, tenure and age are for the PARENT company (提出会社) only - that is
# what the annual report discloses. Headcount is the consolidated group where
# the firm consolidates.
# ----------------------------------------------------------------------------
LABOR_FIELDS = [
    "country", "native_id", "company_name", "company_name_local", "fiscal_year",
    "period_end", "currency",
    "total_employees", "employees_regular", "employees_contract", "employees_part_time",
    "employees_male", "employees_female", "avg_tenure_years",
    "total_payroll", "avg_salary_per_employee",
    "avg_salary_nonsupervisory", "avg_salary_nonsupervisory_yoy_pct",
    "median_salary_nonsupervisory", "median_salary_nonsupervisory_yoy_pct",
    "avg_benefits_per_employee", "female_manager_share",
    "employee_bonus_cash", "employee_bonus_stock_shares",
    "exec_count", "exec_pay_total", "exec_pay_avg",
    "revenue_per_employee", "payroll_to_revenue",
    "source", "labor_notes",
    # Japan only
    "employees_consolidated", "employees_parent", "avg_age_years",
    "gender_pay_ratio_all_workers", "male_childcare_leave_rate", "female_director_share",
    "doc_id"]
EXEC_PAY_BAND = (1e6, 5e9)       # plausible average pay per officer, JPY
SALARY_BAND = (1.5e6, 4e7)       # plausible average employee salary, JPY
LABOR_ELEMENTS = {
    "employees": ["NumberOfEmployees"],
    "temporary": ["AverageNumberOfTemporaryWorkers", "NumberOfTemporaryWorkers"],
    "age": ["AverageAgeYearsInformationAboutReportingCompanyInformationAboutEmployees"],
    "tenure": ["AverageLengthOfServiceYearsInformationAboutReportingCompany"
               "InformationAboutEmployees"],
    "salary": ["AverageAnnualSalaryInformationAboutReportingCompanyInformationAboutEmployees"],
    "female_mgr": ["RatioOfFemaleEmployeesInManagerialPositionsMetricsOfReportingCompany"],
    "pay_gap": ["AllEmployeesDifferencesInWagesBetweenMaleAndFemaleEmployeesMetricsOf"
                "ReportingCompany"],
    "female_dir": ["RatioOfFemaleDirectorsAndOtherOfficers"],
}
LABOR_CAPTION = {               # fallback on the Japanese label
    "temporary": r"臨時従業員",
    "age": r"^平均年齢", "tenure": r"^平均勤続年数", "salary": r"^平均年間給与",
    "female_mgr": r"管理職に占める女性",
    "pay_gap": r"(男女の賃金の差異.*全労働者|全労働者.*男女の賃金の差異)",
}
CHILDCARE_SUFFIX = "RatioOfMaleEmployeesTakingChildcareLeaveMetricsOfReportingCompany"
EXEC_AMOUNT = re.compile(r"^TotalAmountOfRemuneration.*ByCategoryOfDirectorsAndOtherOfficers$")
EXEC_COUNT = re.compile(r"^NumberOf.*ByCategoryOfDirectorsAndOtherOfficers$")


# =============================================================================
# EDINET client
# =============================================================================
class EdinetError(SystemExit):
    pass


TLS_HELP = ("TLS certificate check failed - usually antivirus or a company proxy "
            "inspecting HTTPS. Fix: pip install truststore (the script then trusts "
            "your system's certificates), or pass --ca-bundle path\\to\\company-root.pem.")
KEY_HELP = ("Get a free key at https://api.edinet-fsa.go.jp/api/auth/index.aspx?mode=1 "
            "(steps at the top of this script), then set EDINET_KEY or pass --key.")


class Edinet:
    def __init__(self, key, rate_limit=RATE_LIMIT, raw_dir=RAW_DIR, api=API, ca_bundle=None):
        self.key, self.rate, self.api, self.raw = key, rate_limit, api.rstrip("/"), raw_dir
        self.s = requests.Session()
        if ca_bundle:
            self.s.verify = ca_bundle
        self.s.headers["User-Agent"] = "research-panel/1.0 (python-requests)"
        self.calls, self.bytes = 0, 0
        self.in_flight = None
        self._last = 0.0
        for sub in ("lists", "docs"):
            os.makedirs(os.path.join(raw_dir, sub), exist_ok=True)
        threading.Thread(target=self._watchdog, daemon=True).start()

    # The script can only go quiet inside one call; say so when one runs long.
    def _watchdog(self):
        last, warned = None, 0.0
        while True:
            time.sleep(5)
            job = self.in_flight
            if job is not last:
                last, warned = job, 0.0
            if job is None:
                continue
            waited = time.monotonic() - job[1]
            if waited >= STALL_WARN_SECONDS and waited - warned >= STALL_WARN_SECONDS:
                warned = waited
                log.warning("still waiting on EDINET (%s) after %.0fs - slow server or "
                            "large file; the script has not frozen", job[0], waited)

    def redact(self, text):
        text = str(text)
        return text.replace(self.key, "***") if self.key else text

    def _get(self, url, params, what, stream=False):
        """GET with pacing, retries and automatic slow-down. Never logs the key."""
        attempt = 0
        while True:
            wait = self.rate - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self.in_flight = (what, time.monotonic())
            try:
                r = self.s.get(url, params=params, timeout=(20, 180))
                content = r.content
            except requests.exceptions.SSLError as e:
                raise EdinetError(f"{TLS_HELP}\n({self.redact(e)})")
            except (requests.ConnectionError, requests.Timeout,
                    requests.exceptions.ChunkedEncodingError) as e:
                r, content, err = None, b"", e
            finally:
                self.in_flight = None
                self._last = time.monotonic()
                self.calls += 1
            if r is not None and r.status_code not in (429, 500, 502, 503, 504):
                self.bytes += len(content)
                return r
            attempt += 1
            reason = f"HTTP {r.status_code}" if r is not None else \
                f"connection dropped ({type(err).__name__})"
            if attempt > 6:
                raise ConnectionError(f"{what}: gave up after 6 retries ({reason}): "
                                      f"{self.redact(err) if r is None else ''}")
            # EDINET drops connections when called too fast: slow down for good
            new_rate = min(max(self.rate * 1.5, self.rate + 0.5), MAX_RATE_LIMIT)
            if new_rate > self.rate:
                log.warning("%s for %s - slowing to one call every %.1fs", reason, what,
                            new_rate)
                self.rate = new_rate
            pause = min(5 * 2 ** (attempt - 1), 120)
            log.warning("retry %d/6 for %s in %ds", attempt, what, pause)
            time.sleep(pause)

    @staticmethod
    def _api_error(r):
        """(status, message) from an EDINET JSON body, or None if it isn't one."""
        try:
            body = r.json()
        except ValueError:
            return None
        if not isinstance(body, dict):
            return None
        if "StatusCode" in body or "statusCode" in body:
            return str(body.get("StatusCode", body.get("statusCode"))), \
                str(body.get("message", ""))
        meta = body.get("metadata")
        if isinstance(meta, dict) and str(meta.get("status", "200")) != "200":
            return str(meta.get("status")), str(meta.get("message", ""))
        return None

    def _fatal_if_auth(self, status, message):
        if status in ("401", "403"):
            raise EdinetError(f"EDINET refused the API key (status {status}: "
                              f"{self.redact(message)}).\n{KEY_HELP}")

    def doc_list(self, day):
        """Annual-report rows filed on `day`, cached on disk once the day is final."""
        path = os.path.join(self.raw, "lists", f"{day.isoformat()}.json")
        final = (dt.date.today() - day).days > LIST_FINAL_AFTER_DAYS
        if os.path.exists(path) and final:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh), True
        r = self._get(f"{self.api}/documents.json",
                      {"date": day.isoformat(), "type": 2, "Subscription-Key": self.key},
                      f"list {day}")
        err = self._api_error(r)
        if r.status_code in (401, 403) or (err and err[0] in ("401", "403")):
            self._fatal_if_auth(err[0] if err else str(r.status_code),
                                err[1] if err else r.text[:200])
        if err or r.status_code != 200:
            status, msg = err or (str(r.status_code), r.text[:200])
            raise ConnectionError(f"EDINET list for {day} failed: {status} "
                                  f"{self.redact(msg)}")
        rows = [x for x in (r.json().get("results") or [])
                if x.get("docID") and x.get("docTypeCode") in (ANNUAL_REPORT, AMENDMENT)]
        keep = ["docID", "edinetCode", "secCode", "filerName", "ordinanceCode", "formCode",
                "docTypeCode", "periodStart", "periodEnd", "submitDateTime",
                "docDescription", "parentDocID", "withdrawalStatus", "xbrlFlag", "csvFlag"]
        rows = [{k: x.get(k) for k in keep} for x in rows]
        tmp = path + ".part"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False)
        os.replace(tmp, path)
        return rows, False

    def download(self, doc_id):
        """The CSV-conversion ZIP for a filing -> local path, or (None, reason)."""
        if not re.fullmatch(r"[A-Z0-9]{8}", doc_id or ""):
            return None, "bad docID"
        path = os.path.join(self.raw, "docs", f"{doc_id}.zip")
        if os.path.exists(path) and zipfile.is_zipfile(path):
            return path, "cached"
        r = self._get(f"{self.api}/documents/{doc_id}",
                      {"type": 5, "Subscription-Key": self.key}, f"doc {doc_id}")
        if r.content[:2] != b"PK":
            err = self._api_error(r) or (str(r.status_code), r.text[:200])
            self._fatal_if_auth(*err)
            return None, f"EDINET {err[0]}: {self.redact(err[1])}".strip()
        tmp = path + ".part"
        with open(tmp, "wb") as fh:
            fh.write(r.content)
        if not zipfile.is_zipfile(tmp):
            os.remove(tmp)
            return None, "corrupt ZIP"
        os.replace(tmp, path)
        return path, "downloaded"

    def codelist(self, local=None):
        """Path to EDINET's code list ZIP/CSV (refreshed weekly)."""
        if local:
            return local
        path = os.path.join(self.raw, "Edinetcode.zip")
        fresh = os.path.exists(path) and \
            time.time() - os.path.getmtime(path) < CODELIST_MAX_AGE_DAYS * 86400
        if not fresh:
            log.info("downloading EDINET code list (no key needed)")
            try:
                r = self._get(CODELIST_URL, {}, "code list")
            except ConnectionError:
                r = None
            if r is not None and r.status_code == 200 and r.content[:2] == b"PK":
                with open(path + ".part", "wb") as fh:
                    fh.write(r.content)
                os.replace(path + ".part", path)
            elif os.path.exists(path):
                log.warning("code list download failed; using the copy from %s",
                            time.ctime(os.path.getmtime(path)))
            else:
                raise EdinetError(
                    f"could not download {CODELIST_URL}. Download it in a browser, "
                    f"then pass --codelist path\\to\\Edinetcode.zip")
        return path


# =============================================================================
# Helpers
# =============================================================================
def fmt_secs(s):
    s = int(max(s, 0))
    return f"{s // 3600}h{s % 3600 // 60:02d}m" if s >= 3600 else f"{s // 60}m{s % 60:02d}s"


class Progress:
    """Plain-text status lines at least every HEARTBEAT_SECONDS, with an ETA."""

    def __init__(self, label, total, api=None):
        self.label, self.total, self.api = label, total, api
        self.done, self.stats = 0, {}
        self.t0 = self.last = time.monotonic()

    def tick(self, current="", **stats):
        self.done += 1
        self.stats.update(stats)
        now = time.monotonic()
        if now - self.last >= HEARTBEAT_SECONDS or self.done == self.total:
            self.last = now
            elapsed = now - self.t0
            rate = self.done / elapsed if elapsed else 0
            eta = fmt_secs((self.total - self.done) / rate) if rate else "?"
            extra = "".join(f" | {k} {v:,}" for k, v in self.stats.items())
            net = (f" | EDINET calls {self.api.calls:,}, {self.api.bytes / 1e6:,.0f} MB"
                   if self.api else "")
            log.info("%s %d/%d (%.0f%%)%s%s | elapsed %s, ETA %s%s", self.label, self.done,
                     self.total, 100 * self.done / max(self.total, 1), extra, net,
                     fmt_secs(elapsed), eta, f" | at: {current}" if current else "")


def fiscal_year(period_end):
    """Compustat rule: a year ending Jan-May belongs to the previous fiscal year."""
    return period_end.year if period_end.month >= 6 else period_end.year - 1


def parse_date(text):
    try:
        return dt.date.fromisoformat(str(text or "")[:10])
    except ValueError:
        return None


def num_str(v):
    if v is None:
        return NA
    if float(v).is_integer() and abs(v) < 1e18:
        return str(int(v))
    return f"{v:.6g}" if abs(v) < 1 else f"{v:.4f}".rstrip("0").rstrip(".")


_NIL = {"", "-", "－", "―", "‐", "—", "ー", "nan", "None"}


def to_number(text):
    t = unicodedata.normalize("NFKC", str(text or "")).strip().replace(",", "")
    if t in _NIL:
        return None
    neg = t.startswith("△") or t.startswith("▲")
    t = t.lstrip("△▲")
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def norm_label(text):
    t = unicodedata.normalize("NFKC", str(text or ""))
    t = re.sub(r"\s+", "", t)
    return re.sub(r"[、,](経営指標等|連結|提出会社|個別).*$", "", t)


def stock_code4(sec):
    s = str(sec or "").strip()
    return s[:4] if len(s) == 5 and s.endswith("0") else s


# =============================================================================
# Frame: listed firms from EDINET's code list
# =============================================================================
CODELIST_COLS = {"edinet": ("ＥＤＩＮＥＴコード", 0), "type": ("提出者種別", 1),
                 "listed": ("上場区分", 2), "consolidated": ("連結の有無", 3),
                 "capital": ("資本金", 4), "fye": ("決算日", 5), "name": ("提出者名", 6),
                 "name_en": ("提出者名（英字）", 7), "address": ("所在地", 9),
                 "industry": ("提出者業種", 10), "sec": ("証券コード", 11),
                 "jcn": ("提出者法人番号", 12)}


def read_codelist(path):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            name = next(n for n in z.namelist() if n.lower().endswith(".csv"))
            raw = z.read(name)
    else:
        with open(path, "rb") as fh:
            raw = fh.read()
    text = None
    for enc in ("cp932", "utf-8-sig", "utf-16"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    rows = list(csv.reader(io.StringIO(text)))
    # the first line is "download date, count"; find the real header
    h = next((i for i, r in enumerate(rows[:5])
              if r and "EDINET" in unicodedata.normalize("NFKC", r[0]).upper()), 1)
    header = [unicodedata.normalize("NFKC", c).strip() for c in rows[h]]
    pos = {}
    for key, (label, default) in CODELIST_COLS.items():
        label = unicodedata.normalize("NFKC", label)
        pos[key] = header.index(label) if label in header else default
    out = []
    for r in rows[h + 1:]:
        if len(r) <= max(pos.values()):
            continue
        out.append({k: r[i].strip() for k, i in pos.items()})
    return out


def build_frame(codelist_rows, include_foreign=False):
    frame = []
    for r in codelist_rows:
        if r["listed"] != "上場":
            continue
        domestic = r["type"].startswith("内国法人")
        if not (domestic or include_foreign):
            continue
        ind_en, isic = industry(r["industry"])
        frame.append({"native_id": r["edinet"], "stock_code": stock_code4(r["sec"]),
                      "sec_code5": r["sec"], "company_name": r["name_en"],
                      "company_name_local": r["name"], "filer_type": r["type"],
                      "consolidated_flag": r["consolidated"], "fiscal_year_end": r["fye"],
                      "capital_million_yen": r["capital"], "native_industry_code": r["industry"],
                      "industry_en": ind_en, "isic_section": isic,
                      "corporate_number": r["jcn"]})
    return frame


def write_csv(path, rows, fields):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({f: r.get(f, "") for f in fields})


FRAME_FIELDS = ["native_id", "stock_code", "sec_code5", "company_name", "company_name_local",
                "filer_type", "consolidated_flag", "fiscal_year_end", "capital_million_yen",
                "native_industry_code", "industry_en", "isic_section", "corporate_number"]


# =============================================================================
# Scan the daily lists and pick one annual report per firm-year
# =============================================================================
def scan(api, first, last):
    days = [first + dt.timedelta(d) for d in range((last - first).days + 1)]
    prog = Progress("scan daily lists", len(days), api)
    rows, cached, failed = [], 0, []
    for day in tqdm(days, desc="daily lists", unit="day", disable=not SHOW_BAR):
        try:
            got, hit = api.doc_list(day)
        except ConnectionError as e:
            log.warning("%s", api.redact(e))
            failed.append(day.isoformat())
            got, hit = [], False
        rows += got
        cached += hit
        prog.tick(day.isoformat(), annual_reports=sum(r["docTypeCode"] == ANNUAL_REPORT
                                                      for r in rows))
    log.info("scanned %d days (%d from disk): %d annual reports, %d amendments", len(days),
             cached, sum(r["docTypeCode"] == ANNUAL_REPORT for r in rows),
             sum(r["docTypeCode"] == AMENDMENT for r in rows))
    if failed:
        log.warning("%d day(s) could not be listed (%s%s). Filings from those days are "
                    "missing; rerun the same command later to fill them in.", len(failed),
                    ", ".join(failed[:5]), "..." if len(failed) > 5 else "")
    return rows


def choose(rows, frame, fy_start, fy_end):
    """Latest original annual report per (firm, fiscal year) in the frame."""
    ids = {f["native_id"] for f in frame}
    amended = defaultdict(list)
    for r in rows:
        if r["docTypeCode"] == AMENDMENT and r.get("parentDocID"):
            amended[r["parentDocID"]].append(r["docID"])
    best, skipped = {}, Counter()
    for r in rows:
        if r["docTypeCode"] != ANNUAL_REPORT or r.get("edinetCode") not in ids:
            continue
        if str(r.get("withdrawalStatus") or "0") != "0":
            skipped["withdrawn"] += 1
            continue
        pe = parse_date(r.get("periodEnd"))
        if pe is None:
            skipped["no period end"] += 1
            continue
        fy = fiscal_year(pe)
        if not fy_start <= fy <= fy_end:
            continue
        key = (r["edinetCode"], fy)
        if key not in best or (r.get("submitDateTime") or "") > \
                (best[key].get("submitDateTime") or ""):
            best[key] = dict(r, fiscal_year=fy, amended_by=";".join(amended[r["docID"]]))
    if skipped:
        log.info("skipped annual reports: %s", dict(skipped))
    return sorted(best.values(), key=lambda r: (r["submitDateTime"] or "", r["docID"]))


# =============================================================================
# Parse EDINET's CSV conversion
# =============================================================================
csv.field_size_limit(2 ** 31 - 1)
CSV_HEADER = ["要素ID", "項目名", "コンテキストID", "相対年度", "連結・個別", "期間・時点",
              "ユニットID", "単位", "値"]


class Fact:
    __slots__ = ("prefix", "local", "label", "context", "base", "scope", "members",
                 "unit", "value", "num")

    def __init__(self, element, label, context, unit, value):
        self.prefix, _, self.local = element.rpartition(":")
        self.label, self.context, self.unit, self.value = label, context, unit, value
        self.base, _, self.members = context.partition("_")
        if not self.members:
            self.scope = "total"
        elif self.members.endswith("NonConsolidatedMember") and \
                self.members.count("Member") == 1:
            self.scope = "parent"
        else:
            self.scope = "dim"
        self.num = None if self.local.endswith("TextBlock") else to_number(value)

    @property
    def element(self):
        return f"{self.prefix}:{self.local}" if self.prefix else self.local


def decode_table(raw):
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        encodings = ["utf-16"]
    elif raw[:3] == b"\xef\xbb\xbf":
        encodings = ["utf-8-sig"]
    else:
        encodings = ["utf-8", "utf-16-le", "cp932"]
    for enc in encodings:
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        if "\t" in text[:5000] and "\x00" not in text[:5000]:
            return list(csv.reader(io.StringIO(text), delimiter="\t"))
    return []


def parse_zip(path):
    """All facts in a filing's CSV ZIP (audit-report CSVs skipped)."""
    facts = []
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith(".csv")
                 and "__macosx" not in n.lower()
                 and not os.path.basename(n).startswith("jpaud")]
        for name in names:
            rows = decode_table(z.read(name))
            if not rows:
                continue
            head = [c.strip() for c in rows[0]]
            if "要素ID" in head:
                idx = [head.index(c) if c in head else i for i, c in enumerate(CSV_HEADER)]
                rows = rows[1:]
            else:
                idx = list(range(9))
            for r in rows:
                if len(r) < 9 or r[idx[0]] == "要素ID":
                    continue
                facts.append(Fact(r[idx[0]].strip(), r[idx[1]].strip(), r[idx[2]].strip(),
                                  r[idx[6]].strip(), r[idx[8]].strip()))
    return facts


class Filing:
    """Index over one filing's facts, standard taxonomy elements only."""

    def __init__(self, facts):
        self.facts = facts
        self.idx = {}
        for f in facts:
            if f.prefix in STD_PREFIXES:
                self.idx.setdefault((f.local, f.base, f.scope), f)
        self.dei = {f.local: f.value for f in facts if f.prefix == "jpdei_cor"}

    def get(self, names, bases, scopes, numeric=True):
        for name in names:
            for scope in scopes:
                for base in bases:
                    f = self.idx.get((name, base, scope))
                    if f is not None and (f.num is not None or not numeric):
                        return f
        return None

    def by_caption(self, pattern, deny, bases, scopes, money=True):
        pat, bad = re.compile(pattern), re.compile(deny) if deny else None
        for scope in scopes:
            for f in self.facts:
                if f.scope != scope or f.base not in bases or f.num is None:
                    continue
                if money and not re.fullmatch(r"[A-Z]{3}", f.unit or ""):
                    continue
                lab = norm_label(f.label)
                if pat.search(lab) and not (bad and bad.search(lab)):
                    return f
        return None


def basis_of(filing, frame_row):
    flag = str(filing.dei.get("WhetherConsolidatedFinancialStatementsArePreparedDEI", "")
               ).strip().lower()
    if flag in ("true", "false"):
        consolidated = flag == "true"
    elif frame_row.get("consolidated_flag") in ("有", "無"):
        consolidated = frame_row["consolidated_flag"] == "有"
    else:
        consolidated = any(f.scope == "total" and f.prefix in ("jppfs_cor", "jpigp_cor")
                           and f.base in (CUR_DUR, CUR_INST) for f in filing.facts)
    if consolidated:
        return "consolidated", ["total"]
    return "separate_no_cfs", ["parent", "total"]


def extract_core(filing, scopes):
    vals, src, cur = {}, [], None
    for var in VARS:
        bases = [CUR_DUR] if var in DURATION_VARS else [CUR_INST]
        f = filing.get(LADDER[var], bases, scopes)
        how = f.local if f else ""
        if f is None and var in CAPTION:
            f = filing.by_caption(*CAPTION[var], bases, scopes)
            how = f"caption:{norm_label(f.label)}" if f else ""
        v = f.num if f else None
        if v is not None and var in ABS_VARS:
            v = abs(v)
        vals[var] = v
        if f is not None:
            src.append(f"{var}={how}")
            if cur is None and re.fullmatch(r"[A-Z]{3}", f.unit or ""):
                cur = f.unit
    return vals, src, cur or "JPY"


def check(v, tol=0.01):
    close = lambda a, b: abs(a - b) <= tol * max(abs(a), abs(b), 1)
    bad = []
    if None not in (v["total_assets"], v["total_liabilities"], v["shareholders_equity"]) and \
            not close(v["total_assets"], v["total_liabilities"] + v["shareholders_equity"]):
        bad.append("A!=L+E")
    if None not in (v["total_revenue"], v["cogs"], v["gross_profit"]) and \
            not close(v["gross_profit"], v["total_revenue"] - v["cogs"]):
        bad.append("GP!=REV-COGS")
    return ";".join(bad) or "ok"


# ----------------------------------------------------------------------------
# Panel V2
# ----------------------------------------------------------------------------
def accumulated_depreciation(filing, scopes):
    """(value, how): one total line if filed, else the sum of per-class lines."""
    for scope in scopes:
        cands = [f for f in filing.facts if f.prefix in STD_PREFIXES and f.scope == scope
                 and f.base == CUR_INST and f.num is not None
                 and f.local.startswith("AccumulatedDepreciation")]
        if not cands:
            continue
        totals = [f for f in cands if "PropertyPlantAndEquipment" in f.local]
        if totals:
            f = max(totals, key=lambda x: abs(x.num))
            return abs(f.num), f.local
        classes = [f for f in cands if not re.search(
            r"Intangible|Investment|RealEstate|Total|Software|Goodwill", f.local)]
        if classes:
            return sum(abs(f.num) for f in classes), f"sum of {len(classes)} class lines"
    return None, ""


def v2_extract(filing, scopes, core):
    out, proxies, used, found = {}, [], [], 0
    for spec in V2_FIELDS:
        bases = [CUR_DUR] if spec["kind"] == "duration" else [CUR_INST]
        value, how = None, ""
        f = filing.get(spec["elements"], bases, scopes) if spec["elements"] else None
        if f is not None:
            value, how = f.num, f.local
        if value is None and spec.get("derive") == "acc_dep":
            value, how = accumulated_depreciation(filing, scopes)
            if value is not None:
                proxies.append(f"{spec['col']}<-{how}")
        if value is None and spec.get("derive") == "ppe_gross":
            net = filing.get(["PropertyPlantAndEquipment"], bases, scopes)
            acc, acc_how = accumulated_depreciation(filing, scopes)
            if net is not None and acc:
                value, how = net.num + acc, "PropertyPlantAndEquipment+acc. depreciation"
                proxies.append(f"{spec['col']}=net+{acc_how}")
        if value is None and spec.get("proxy"):
            f = filing.get(spec["proxy"], bases, scopes)
            if f is not None:
                value, how = f.num, f.local
                proxies.append(f"{spec['col']}<-{f.local}")
        if value is not None:
            if spec.get("abs"):
                value = abs(value)
            value *= spec.get("sign", 1)
            used.append(how)
            found += 1
        out[spec["col"]] = num_str(value)
    if out["TotalEmployees"] == NA and core.get("_employees"):
        out["TotalEmployees"] = num_str(core["_employees"])
        found += 1
    return out, found, proxies, used


def write_v2(path, coverage_path, rows):
    cols = V2_META + [s["col"] for s in V2_FIELDS] + V2_TAIL
    write_csv(path, rows, cols)
    n = max(len(rows), 1)
    log.info("=" * 74)
    log.info("Panel V2: %d firm-years -> %s", len(rows), path)
    with open(coverage_path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["field", "jp_elements", "jp_proxies", "firm_years_with_value", "share",
                    "share_from_proxy", "note"])
        for spec in V2_FIELDS:
            got = sum(1 for r in rows if r.get(spec["col"], NA) != NA)
            prox = sum(1 for r in rows if f"{spec['col']}<-" in r.get("proxies_used", "")
                       or f"{spec['col']}=" in r.get("proxies_used", ""))
            log.info("  %-58s %6.1f%%%s", spec["col"][:58], 100 * got / n,
                     f"  ({100 * prox / n:.0f}% proxy)" if prox else "")
            w.writerow([spec["col"], ";".join(spec["elements"]),
                        ";".join(spec.get("proxy", [])) or spec.get("derive", ""), got,
                        f"{got / n:.3f}", f"{prox / n:.3f}", spec.get("note", "")])
    log.info("coverage table -> %s", coverage_path)


# ----------------------------------------------------------------------------
# Labor
# ----------------------------------------------------------------------------
LABOR_BASES = [CUR_INST, CUR_DUR, FILING]


def labor_value(filing, key, scopes, numeric=True):
    f = filing.get(LABOR_ELEMENTS.get(key, []), LABOR_BASES, scopes, numeric)
    if f is None and key in LABOR_CAPTION:
        f = filing.by_caption(LABOR_CAPTION[key], "", LABOR_BASES, scopes, money=False)
    return f


def as_share(f, notes, name):
    """Ratios are filed as fractions (0.052 = 5.2%); a few filers type percents."""
    if f is None or f.num is None:
        return None
    v = f.num
    if v > 1.5:
        notes.append(f"{name} filed as percent, divided by 100")
        v /= 100
    return v


def exec_pay(filing):
    """Officer pay by category (役員区分ごとの報酬等), summed over categories."""
    amounts, counts = defaultdict(float), defaultdict(float)
    for f in filing.facts:
        if f.base != CUR_DUR or f.num is None or f.scope == "total":
            continue
        if re.search(r"Total|合計", f.members):
            continue
        lab = norm_label(f.label)
        if EXEC_AMOUNT.match(f.local) or (f.prefix not in STD_PREFIXES and "報酬等の総額" in lab):
            amounts[f.members] = max(amounts[f.members], f.num)
        elif EXEC_COUNT.match(f.local) or (f.prefix not in STD_PREFIXES and "員数" in lab
                                            and "役員" in lab):
            counts[f.members] = max(counts[f.members], f.num)
    total = sum(amounts.values()) or None
    count = sum(counts.values()) or None
    return total, count, len(amounts)


def labor_row(filing, frame_row, base, scopes, core, parent_rev):
    row = {f: NA for f in LABOR_FIELDS}
    row.update({k: base[k] for k in ("native_id", "company_name", "company_name_local",
                                     "fiscal_year", "period_end", "doc_id")})
    row.update({"country": "JP", "currency": "JPY",
                "source": "EDINET annual securities report (従業員の状況, 役員の報酬等)"})
    notes = []
    consolidated = scopes == ["total"]
    cons = filing.get(["NumberOfEmployees"], [CUR_INST], ["total"]) if consolidated else None
    par = filing.get(["NumberOfEmployees"], [CUR_INST], ["parent"]) or \
        (None if consolidated else filing.get(["NumberOfEmployees"], [CUR_INST], ["total"]))
    n_cons = cons.num if cons else None
    n_par = par.num if par else None
    total = n_cons if n_cons is not None else n_par
    row["employees_consolidated"] = num_str(n_cons)
    row["employees_parent"] = num_str(n_par)
    row["total_employees"] = num_str(total)
    if n_cons is None and n_par is not None and consolidated:
        notes.append("group headcount not tagged; total_employees is parent only")
    temp = labor_value(filing, "temporary", ["total"] if consolidated else scopes)
    if temp is not None:
        row["employees_part_time"] = num_str(temp.num)
        notes.append("employees_part_time = average temporary workers (臨時従業員), "
                     "not included in total_employees")
    pscopes = ["parent", "total"]
    age = labor_value(filing, "age", pscopes)
    ten = labor_value(filing, "tenure", pscopes)
    sal = labor_value(filing, "salary", pscopes)
    if age:
        row["avg_age_years"] = num_str(round(age.num, 2))
    if ten:
        row["avg_tenure_years"] = num_str(round(ten.num, 2))
    salary = sal.num if sal else None
    if salary is not None and not SALARY_BAND[0] <= salary <= SALARY_BAND[1]:
        if SALARY_BAND[0] <= salary * 1000 <= SALARY_BAND[1]:
            salary *= 1000
            notes.append("avg salary filed in thousand yen")
        else:
            notes.append(f"avg salary {salary:,.0f} outside plausible range")
    if salary is not None:
        row["avg_salary_per_employee"] = num_str(round(salary))
        if n_par:
            payroll = salary * n_par
            row["total_payroll"] = num_str(round(payroll))
            notes.append("total_payroll = parent avg salary x parent employees (estimate)")
            if parent_rev:
                row["payroll_to_revenue"] = f"{payroll / parent_rev:.4f}"
    fm = as_share(labor_value(filing, "female_mgr", pscopes), notes, "female manager share")
    pg = as_share(labor_value(filing, "pay_gap", pscopes), notes, "gender pay ratio")
    fd = as_share(labor_value(filing, "female_dir", pscopes), notes, "female director share")
    row["female_manager_share"] = num_str(fm)
    row["gender_pay_ratio_all_workers"] = num_str(pg)
    row["female_director_share"] = num_str(fd)
    cc = next((f for f in filing.facts if f.local.endswith(CHILDCARE_SUFFIX)
               and f.scope in ("total", "parent") and f.base in LABOR_BASES
               and f.num is not None), None)
    row["male_childcare_leave_rate"] = num_str(as_share(cc, notes, "childcare leave rate"))
    total_pay, count, cats = exec_pay(filing)
    if count:
        row["exec_count"] = num_str(count)
    if total_pay:
        row["exec_pay_total"] = num_str(round(total_pay))
        notes.append(f"exec pay summed over {cats} officer categories")
        if count:
            avg = total_pay / count
            row["exec_pay_avg"] = num_str(round(avg))
            if not EXEC_PAY_BAND[0] <= avg <= EXEC_PAY_BAND[1]:
                notes.append("exec pay average implausible - check units")
    rev = core.get("total_revenue")
    if rev and total:
        row["revenue_per_employee"] = num_str(round(rev / total))
    if total is None:
        notes.append("no headcount tagged")
    row["labor_notes"] = "; ".join(notes)
    return row


def write_labor(path, rows):
    write_csv(path, rows, LABOR_FIELDS)
    n = max(len(rows), 1)
    log.info("=" * 74)
    log.info("labor panel: %d firm-years -> %s", len(rows), path)
    for f in ("total_employees", "employees_part_time", "avg_salary_per_employee",
              "avg_tenure_years", "avg_age_years", "female_manager_share",
              "gender_pay_ratio_all_workers", "male_childcare_leave_rate", "exec_pay_total",
              "revenue_per_employee"):
        got = sum(1 for r in rows if r[f] not in (NA, "", None))
        log.info("  %-30s %5.1f%%", f, 100 * got / n)


# ----------------------------------------------------------------------------
# English labels from element names, wide and long files
# ----------------------------------------------------------------------------
SUFFIXES = [("InformationAboutReportingCompanyInformationAboutEmployees", "parent"),
            ("MetricsOfReportingCompany", "parent"),
            ("SummaryOfBusinessResults", "summary"), ("USGAAP", "US GAAP"),
            ("IFRS", "IFRS"), ("JMIS", "JMIS"), ("InvCF", "investing CF"),
            ("OpeCF", "operating CF"), ("FinCF", "financing CF"), ("SGA", "SG&A"),
            ("NOI", "non-operating income"), ("NOE", "non-operating expenses"),
            ("EI", "extraordinary income"), ("EL", "extraordinary loss"),
            ("NCA", "non-current assets"), ("NCL", "non-current liabilities"),
            ("CA", "current assets"), ("CL", "current liabilities"),
            ("MCR", "manufacturing cost"), ("DEI", "document info")]
KEEP_CASE = {"IFRS", "GAAP", "US", "CF", "SG&A", "JMIS", "DEI", "EDINET", "ROE", "EPS",
             "BPS", "PER", "R&D"}


PHRASES = [("profit loss", "profit (loss)"), ("income loss", "income (loss)"),
           ("decrease increase", "decrease (increase)"),
           ("increase decrease", "increase (decrease)"),
           ("earnings loss", "earnings (loss)"),
           ("property plant and equipment", "property, plant and equipment"),
           ("selling general and", "selling, general and")]


def english_label(local):
    # the childcare-leave elements carry the full name of the statute in front
    local = re.sub(r"^.*?(RatioOfMaleEmployeesTakingChildcareLeave)", r"\1", local)
    name, tags = local, []
    changed = True
    while changed:
        changed = False
        for suf, tag in sorted(SUFFIXES, key=lambda x: -len(x[0])):
            if name.endswith(suf) and len(name) > len(suf) + 2:
                name, changed = name[:-len(suf)], True
                tags.insert(0, tag)
                break
    words = re.findall(r"[A-Z]{2,}(?=[A-Z][a-z]|\d|$)|[A-Z]?[a-z]+|[A-Z]|\d+", name)
    out = []
    for i, w in enumerate(words):
        if w.isupper() and (w in KEEP_CASE or len(w) > 1):
            out.append(w)
        else:
            out.append(w.capitalize() if i == 0 else w.lower())
    text = " ".join(out) or local
    for a, b in PHRASES:
        text = re.sub(re.escape(a), lambda m: (b[0].upper() if m.group(0)[0].isupper()
                                               else b[0]) + b[1:], text, flags=re.I)
    return text + (f" ({', '.join(tags)})" if tags else "")


_LABEL_CACHE = {}


def label_en(local):
    if local not in _LABEL_CACHE:
        _LABEL_CACHE[local] = english_label(local)
    return _LABEL_CACHE[local]


LONG_FIELDS = ["native_id", "stock_code", "fiscal_year", "period_end", "doc_id", "element_id",
               "taxonomy", "label_en", "label_ja", "context_id", "scope", "period",
               "unit", "value"]


def long_rows(filing, base):
    for f in filing.facts:
        if f.base not in (CUR_DUR, CUR_INST, FILING) or f.local.endswith("TextBlock"):
            continue
        yield [base["native_id"], base["stock_code"], base["fiscal_year"], base["period_end"],
               base["doc_id"], f.element, TAXONOMY.get(f.prefix, "company extension"),
               label_en(f.local) if f.prefix in STD_PREFIXES else "", f.label, f.context,
               f.scope, f.base, f.unit, f.value]


WIDE_ID = ["native_id", "stock_code", "company_name", "company_name_local", "fiscal_year",
           "period_end", "accounting_standard", "consolidation_basis", "industry_en",
           "isic_section", "doc_id"]


def wide_items(filing, scopes):
    """{element: value} on the panel's basis: standard, non-dimensional, current year."""
    out = {}
    for scope in reversed(scopes):           # first-listed scope wins
        for f in filing.facts:
            if f.scope == scope and f.base in (CUR_DUR, CUR_INST) and \
                    f.prefix in ("jppfs_cor", "jpigp_cor", "jpcrp_cor") and f.num is not None:
                out[f.element] = f.num
    return out


def _snake(text, limit=32):
    s = re.sub(r"[^0-9a-zA-Z]+", "_", text).strip("_").lower()
    return (s or "x")[:limit].rstrip("_")


def write_wide(rows, items, labels_ja, wide_path, dict_path, min_share, ascii_cols):
    n = max(len(rows), 1)
    counts = Counter(e for it in items for e in it)
    keep = sorted((e for e, c in counts.items() if c / n >= min_share),
                  key=lambda e: (-counts[e], e))
    used, colname = set(WIDE_ID), {}
    for e in keep:
        local = e.split(":", 1)[1]
        base = _snake(label_en(local)) if ascii_cols else label_en(local)
        name, k = base, 2
        while name in used:
            suffix = f"_{k}" if ascii_cols else f" [{e}]" if k == 2 else f" [{e}] {k}"
            name = (base[:32 - len(suffix)] + suffix) if ascii_cols else base + suffix
            k += 1
        used.add(name)
        colname[e] = name
    with open(wide_path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(WIDE_ID + [colname[e] for e in keep])
        for r, it in zip(rows, items):
            w.writerow([r.get(c, "") for c in WIDE_ID] +
                       [num_str(it[e]) if e in it else "" for e in keep])
    with open(dict_path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["column", "element_id", "label_en", "label_ja", "taxonomy",
                    "firm_years", "share"])
        for e in keep:
            prefix, local = e.split(":", 1)
            w.writerow([colname[e], e, label_en(local), labels_ja.get(e, ""),
                        TAXONOMY.get(prefix, ""), counts[e], f"{counts[e] / n:.3f}"])
    log.info("wide: %d firm-years x %d line items (of %d distinct; rest are below %.0f%% "
             "coverage and stay in the long file) -> %s", len(rows), len(keep), len(counts),
             100 * min_share, wide_path)
    log.info("dictionary -> %s", dict_path)


# =============================================================================
# Main
# =============================================================================
def main(argv=None):
    global SHOW_BAR, HEARTBEAT_SECONDS
    p = argparse.ArgumentParser(description="Japanese listed-firm financials from EDINET.")
    p.add_argument("--key", default=os.environ.get("EDINET_KEY"),
                   help="EDINET API key; better: set the EDINET_KEY environment variable")
    p.add_argument("--start-year", type=int, default=2025)
    p.add_argument("--end-year", type=int, default=2025)
    p.add_argument("--scan-from", type=parse_date,
                   help="first filing date to scan (default: June 1 of --start-year)")
    p.add_argument("--scan-to", type=parse_date,
                   help="last filing date to scan (default: today, or Dec 31 of the "
                        "year after --end-year if earlier)")
    p.add_argument("--include-foreign", action="store_true",
                   help="also listed foreign companies (they mostly file home-GAAP "
                        "statements EDINET does not tag in detail)")
    p.add_argument("--codelist", help="local Edinetcode.zip/.csv instead of downloading")
    p.add_argument("--limit", type=int, help="first N filings only (for testing)")
    p.add_argument("--rate-limit", type=float, default=RATE_LIMIT,
                   help="seconds between EDINET calls (default %(default)s)")
    p.add_argument("--raw-dir", default=RAW_DIR)
    p.add_argument("--ca-bundle", help="PEM file of your company's root certificate, if "
                                       "HTTPS is inspected and truststore is not installed")
    p.add_argument("--out-dir", default=".", help="folder for the CSV outputs")
    p.add_argument("--labor-only", action="store_true",
                   help="write only panel_labor_jp.csv (reuses downloaded filings)")
    p.add_argument("--no-labor", action="store_true")
    p.add_argument("--no-v2", action="store_true")
    p.add_argument("--no-wide", action="store_true", help="skip wide/long/dictionary")
    p.add_argument("--wide-min-share", type=float, default=WIDE_MIN_SHARE)
    p.add_argument("--ascii-columns", action="store_true",
                   help="Stata-safe column names (<= 32 chars) in wide_jp.csv")
    p.add_argument("--no-bar", action="store_true", help="status lines only, no bars")
    p.add_argument("--heartbeat", type=int, default=HEARTBEAT_SECONDS)
    p.add_argument("--api-base", default=API, help=argparse.SUPPRESS)   # testing/mirrors
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args(argv)
    for stream in (sys.stdout, sys.stderr):       # Japanese on any console
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        datefmt="%H:%M:%S", format="%(asctime)s %(levelname)-7s %(message)s")
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    SHOW_BAR, HEARTBEAT_SECONDS = not args.no_bar, max(args.heartbeat, 1)
    if not args.key:
        p.error("no API key. " + KEY_HELP)
    if args.start_year > args.end_year:
        p.error("--start-year is after --end-year")
    try:
        return run(args)
    except KeyboardInterrupt:
        log.warning("stopped. Everything downloaded so far is kept in %s/ - rerun the "
                    "same command to continue where it left off.", args.raw_dir)
        return 130


def out(args, name):
    return os.path.join(args.out_dir, name)


def run(args):
    os.makedirs(args.out_dir, exist_ok=True)
    api = Edinet(args.key, args.rate_limit, args.raw_dir, args.api_base, args.ca_bundle)

    log.info("=== step 1 of 4: firm list ===")
    frame = build_frame(read_codelist(api.codelist(args.codelist)), args.include_foreign)
    if not frame:
        log.error("no listed firms found in the code list")
        return 1
    write_csv(out(args, "frame_jp.csv"), frame, FRAME_FIELDS)
    log.info("frame: %d listed firms -> frame_jp.csv (by ISIC section: %s)", len(frame),
             dict(Counter(f["isic_section"] for f in frame).most_common()))
    by_id = {f["native_id"]: f for f in frame}

    first = args.scan_from or dt.date(args.start_year, 6, 1)
    last = args.scan_to or min(dt.date.today(), dt.date(args.end_year + 1, 12, 31))
    if last < first:
        log.error("scan window is empty (%s to %s)", first, last)
        return 1
    n_days = (last - first).days + 1
    log.info("=== step 2 of 4: scanning %d daily filing lists (%s to %s), about %s ===",
             n_days, first, last, fmt_secs(n_days * (args.rate_limit + 0.4)))
    rows = scan(api, first, last)
    chosen = choose(rows, frame, args.start_year, args.end_year)
    if args.limit:
        chosen = chosen[:args.limit]
    log.info("%d firm-years with an annual report for FY%d-%d (%d of %d listed firms)",
             len(chosen), args.start_year, args.end_year,
             len({c["edinetCode"] for c in chosen}), len(frame))

    todo = [c for c in chosen if not os.path.exists(
        os.path.join(args.raw_dir, "docs", f"{c['docID']}.zip"))]
    log.info("=== step 3 of 4: downloading %d filings (%d already on disk), about %s ===",
             len(todo), len(chosen) - len(todo), fmt_secs(len(todo) * (args.rate_limit + 1)))
    status = {}
    prog = Progress("download", len(chosen), api)
    for c in tqdm(chosen, desc="filings", unit="doc", disable=not SHOW_BAR):
        if c.get("csvFlag") not in (None, "1", 1):
            status[c["docID"]] = (None, "EDINET has no CSV version of this filing")
        else:
            try:
                status[c["docID"]] = api.download(c["docID"])
            except ConnectionError as e:
                status[c["docID"]] = (None, api.redact(e))
                log.warning("%s (%s): %s", c["docID"], c.get("filerName"), api.redact(e))
        prog.tick(c.get("filerName", ""), ok=sum(1 for v in status.values() if v[0]))

    log.info("=== step 4 of 4: parsing filings ===")
    panel, v2, labor, items, wide_rows, filings_log = [], [], [], [], [], []
    labels_ja = {}
    write_long = not (args.no_wide or args.labor_only)
    long_fh = open(out(args, "long_jp.csv"), "w", newline="", encoding="utf-8-sig") \
        if write_long else None
    long_w = csv.writer(long_fh) if long_fh else None
    if long_w:
        long_w.writerow(LONG_FIELDS)
    done_firms = set()
    prog = Progress("parse", len(chosen))
    try:
        for c in tqdm(chosen, desc="parse", unit="doc", disable=not SHOW_BAR):
            fr = by_id[c["edinetCode"]]
            path, why = status.get(c["docID"], (None, "not downloaded"))
            entry = {"native_id": fr["native_id"], "stock_code": fr["stock_code"],
                     "company_name_local": fr["company_name_local"],
                     "fiscal_year": c["fiscal_year"], "period_end": c.get("periodEnd"),
                     "doc_id": c["docID"], "submitted": c.get("submitDateTime"),
                     "doc_description": c.get("docDescription"),
                     "amended_by": c.get("amended_by", ""), "status": why}
            if not path:
                filings_log.append(entry)
                prog.tick(c["docID"])
                continue
            try:
                filing = Filing(parse_zip(path))
            except (zipfile.BadZipFile, OSError, csv.Error) as e:
                entry["status"] = f"unreadable: {e}"
                filings_log.append(entry)
                prog.tick(c["docID"])
                continue
            if not filing.facts:
                entry["status"] = "no facts in CSV"
                filings_log.append(entry)
                prog.tick(c["docID"])
                continue
            entry["status"] = "parsed"
            filings_log.append(entry)
            done_firms.add(fr["native_id"])
            dei = filing.dei
            pe = parse_date(dei.get("CurrentFiscalYearEndDateDEI")) or \
                parse_date(dei.get("CurrentPeriodEndDateDEI")) or parse_date(c["periodEnd"])
            ps = parse_date(dei.get("CurrentFiscalYearStartDateDEI")) or \
                parse_date(c.get("periodStart"))
            months = round(((pe - ps).days + 1) / 30.44) if pe and ps else ""
            basis, scopes = basis_of(filing, fr)
            standard = (dei.get("AccountingStandardsDEI") or "").strip() or "Japan GAAP"
            base = {"native_id": fr["native_id"], "stock_code": fr["stock_code"],
                    "company_name": dei.get("FilerNameInEnglishDEI") or fr["company_name"],
                    "company_name_local": dei.get("FilerNameInJapaneseDEI")
                    or fr["company_name_local"],
                    "fiscal_year": fiscal_year(pe) if pe else c["fiscal_year"],
                    "period_end": pe.isoformat() if pe else c.get("periodEnd"),
                    "doc_id": c["docID"], "filing_date": (c.get("submitDateTime") or "")[:10],
                    "accounting_standard": standard, "consolidation_basis": basis,
                    "industry_en": fr["industry_en"], "isic_section": fr["isic_section"]}
            core, src, currency = extract_core(filing, scopes)
            emp = filing.get(["NumberOfEmployees"], [CUR_INST], scopes)
            core["_employees"] = emp.num if emp else None
            if not args.labor_only:
                row = dict(base)
                row.update({"country": "JP", "exchange": "JPX", "isin": "",
                            "period_start": ps.isoformat() if ps else "",
                            "period_months": months, "currency": currency, "unit_scale": 1,
                            "listing_status": "listed",
                            "native_industry_code": fr["native_industry_code"]})
                for var in VARS:
                    row[var] = num_str(core[var]) if core[var] is not None else ""
                row["identity_check"] = check(core)
                row["missing_fields"] = ";".join(v for v in VARS if core[v] is None)
                row["sources"] = ";".join(src)
                if months and months != 12:
                    row["identity_check"] += f";{months}-month period"
                panel.append(row)
                if not args.no_v2:
                    vals, found, proxies, used = v2_extract(filing, scopes, core)
                    r2 = dict(base, **vals)
                    r2.update({"fields_found": found, "proxies_used": ";".join(proxies),
                               "elements_used": ";".join(used)})
                    v2.append(r2)
            if not args.no_labor:
                # payroll is the parent's, so divide by the parent's revenue
                if scopes == ["total"]:
                    pr = filing.get(LADDER["total_revenue"], [CUR_DUR], ["parent"])
                    parent_rev = pr.num if pr else None
                else:
                    parent_rev = core["total_revenue"]
                labor.append(labor_row(filing, fr, base, scopes, core, parent_rev))
            if long_w:
                long_w.writerows(long_rows(filing, base))
                items.append(wide_items(filing, scopes))
                wide_rows.append(base)
                for f in filing.facts:
                    if f.prefix in STD_PREFIXES and f.scope in scopes:
                        labels_ja.setdefault(f.element, f.label)
            prog.tick(c["docID"], parsed=len(done_firms))
    finally:
        if long_fh:
            long_fh.close()

    # firms with no annual report in the window
    have = {c["edinetCode"] for c in chosen}
    if not args.limit:
        for fr in frame:
            if fr["native_id"] not in have:
                filings_log.append({"native_id": fr["native_id"], "stock_code": fr["stock_code"],
                                    "company_name_local": fr["company_name_local"],
                                    "status": "no annual report filed in the scan window"})
    write_csv(out(args, "filings_jp.csv"), filings_log,
              ["native_id", "stock_code", "company_name_local", "fiscal_year", "period_end",
               "doc_id", "submitted", "doc_description", "amended_by", "status"])
    log.info("filing status: %s -> filings_jp.csv",
             dict(Counter(e["status"].split(":")[0] for e in filings_log).most_common(6)))

    if not args.labor_only:
        write_csv(out(args, "panel_jp.csv"), panel, FIELDS)
        n = max(len(panel), 1)
        log.info("=" * 74)
        log.info("panel: %d firm-years (%d firms) -> %s", len(panel),
                 len({r["native_id"] for r in panel}), out(args, "panel_jp.csv"))
        log.info("basis: %s | standards: %s",
                 dict(Counter(r["consolidation_basis"] for r in panel)),
                 dict(Counter(r["accounting_standard"] for r in panel)))
        for var in VARS:
            log.info("  %-22s %5.1f%%", var, 100 * sum(1 for r in panel if r[var]) / n)
        flagged = sum(1 for r in panel if not r["identity_check"].startswith("ok"))
        log.info("identity checks: %d ok, %d flagged", len(panel) - flagged, flagged)
        if not args.no_v2:
            write_v2(out(args, "panel_v2_jp.csv"), out(args, "coverage_v2_jp.csv"), v2)
    if not args.no_labor:
        write_labor(out(args, "panel_labor_jp.csv"), labor)
    if long_w:
        log.info("long file (every current-year fact) -> long_jp.csv")
        write_wide(wide_rows, items, labels_ja, out(args, "wide_jp.csv"),
                   out(args, "dictionary_jp.csv"), args.wide_min_share, args.ascii_columns)
    log.info("done: %d EDINET calls, %.0f MB downloaded this run", api.calls, api.bytes / 1e6)
    return 0 if (panel or labor) else 1


if __name__ == "__main__":
    sys.exit(main())
