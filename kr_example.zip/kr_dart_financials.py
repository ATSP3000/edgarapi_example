#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# kr_dart_financials.py - Korean manufacturing firm-year financials from DART
#
# SETUP
#   pip install requests pandas requests-cache tqdm
#   Free API key (40 chars): https://opendart.fss.or.kr  -> 인증키 신청
#
# HOW TO RUN
#   # build the manufacturing frame, then collect (frame is reused if it exists)
#   python3 kr_dart_financials.py --dart-key $KEY --start-year 2020 --end-year 2024
#
#   # review/edit the frame first, then collect from it
#   python3 kr_dart_financials.py --dart-key $KEY --frame-only
#   python3 kr_dart_financials.py --dart-key $KEY --frame frame_kr.csv
#
# INPUT   Nothing but the key. The frame is built from DART's full register
#         (corpCode.xml): by default every firm with a stock code, all sectors.
#         Narrow with --sectors (e.g. --sectors manufacturing, or C,G).
# OUTPUT  frame_kr.csv  - the sample, one row per firm
#         panel_kr.csv  - one row per firm-fiscal-year, values in full KRW
#
# SCOPE - WHAT "ALL FIRMS" MEANS HERE
#   Default:           every CURRENTLY listed firm - KOSPI + KOSDAQ + KONEX
#                      (~2,800 firms), all sectors. Listing status comes from
#                      DART's corp_cls field, so firms that have since left the
#                      market are excluded even if DART still shows a stock code.
#   --include-delisted keep firms DART still links to a stock code but that are
#                      no longer listed (tagged "delisted"). Needed for a
#                      survivorship-free panel over past years.
#   --include-unlisted every DART filer (~100,000). Costs days of API quota just
#                      for the frame, and most unlisted filers have no K-IFRS
#                      statements the endpoint can serve. Only do this deliberately.
#   --extra-firms      CSV of corp_code or corp_name values forced into the
#                      frame regardless of the filters above - e.g. delisted
#                      firms from KRX's KIND delisting history.
#
# FINANCIAL FIRMS (ISIC section K: banks, insurers, securities)
#   Included by default, but their statements have no revenue/COGS in the
#   industrial sense. total_revenue picks up 영업수익 (operating revenue) and
#   cogs/gross_profit are mostly blank. Filter on isic_section before pooling
#   them with industrial firms.
#
# CONSOLIDATION
#   Consolidated (CFS) statements are requested first. A firm with no
#   subsidiaries files only separate (OFS) statements - and for such a firm
#   those ARE the whole firm, so they are used as a fallback and tagged
#   "separate_no_cfs" in consolidation_basis. Excluding them would drop many
#   small KOSDAQ manufacturers for no economic reason. Use --no-ofs-fallback
#   to keep consolidated only.
#
# QUOTA
#   OpenDART allows ~20,000 calls/day per key. All listed firms over 2020-2024
#   is roughly 2,800 calls for the frame plus 1-2 per firm-year - about
#   20,000-22,000 in total, so expect it to spill into a second day. Only
#   successful responses are cached, so a quota-interrupted run resumes where
#   it stopped. If you ran the manufacturing version before, the company-info
#   calls for every listed firm are already cached and the frame is nearly free.
# -----------------------------------------------------------------------------

import argparse, io, logging, os, re, sys, threading, time, zipfile
import xml.etree.ElementTree as ET
import pandas as pd, requests_cache
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from tqdm import tqdm
from tqdm.contrib.logging import logging_redirect_tqdm

# ============================ ADJUST THESE ===================================
RATE_LIMIT = 0.20                    # seconds between uncached calls
CACHE_NAME = "dart_cache"            # sqlite cache; delete the file to refetch
FRAME_PATH = "frame_kr.csv"
PANEL_PATH = "panel_kr.csv"
HEARTBEAT_SECONDS = 20               # plain-text status line at least this often
STALL_WARN_SECONDS = 20              # warn if a single DART call hangs this long
CHECKPOINT_EVERY = 100               # save the panel CSV every N firms
DAILY_QUOTA = 20000                  # OpenDART calls per key per day
SHOW_BAR = True                      # tqdm bars; --no-bar turns them off
# KSIC (10th revision) sections by division range. KSIC is derived from ISIC
# Rev. 4, so the letters line up with ISIC sections; the one quirk is that
# KSIC section C runs to division 34 (industrial machinery repair).
KSIC_SECTIONS = {"A": (1, 3), "B": (5, 8), "C": (10, 34), "D": (35, 35),
                 "E": (36, 39), "F": (41, 42), "G": (45, 47), "H": (49, 52),
                 "I": (55, 56), "J": (58, 63), "K": (64, 66), "L": (68, 68),
                 "M": (70, 73), "N": (74, 76), "O": (84, 84), "P": (85, 85),
                 "Q": (86, 87), "R": (90, 91), "S": (94, 96), "T": (97, 98),
                 "U": (99, 99)}
# =============================================================================

API = "https://opendart.fss.or.kr/api"
VARS = ["total_revenue", "cogs", "gross_profit", "operating_income", "net_income",
        "total_assets", "total_liabilities", "shareholders_equity",
        "cash_and_equivalents", "capex", "rd_expense"]
FIELDS = ["country", "exchange", "native_id", "stock_code", "isin", "company_name",
          "company_name_local", "fiscal_year", "period_end", "consolidation_basis",
          "accounting_standard", "currency", "unit_scale", "listing_status",
          "native_industry_code", "isic_section", *VARS,
          "identity_check", "missing_fields", "rcept_no"]

# Taxonomy ids, tried first. First hit in each ladder wins.
ACCOUNT_IDS = {
    "total_revenue": ["ifrs-full_Revenue", "ifrs-full_RevenueFromContractsWithCustomers",
                      "dart_OperatingRevenue"],
    "cogs": ["ifrs-full_CostOfSales", "dart_CostOfGoodsSold"],
    "gross_profit": ["ifrs-full_GrossProfit"],
    "operating_income": ["dart_OperatingIncomeLoss",
                         "ifrs-full_ProfitLossFromOperatingActivities"],
    "net_income": ["ifrs-full_ProfitLoss", "ifrs-full_ProfitLossAttributableToOwnersOfParent"],
    "total_assets": ["ifrs-full_Assets"],
    "total_liabilities": ["ifrs-full_Liabilities"],
    "shareholders_equity": ["ifrs-full_Equity", "ifrs-full_EquityAttributableToOwnersOfParent"],
    "cash_and_equivalents": ["ifrs-full_CashAndCashEquivalents"],
    "capex": ["ifrs-full_PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities",
              "dart_PurchaseOfPropertyPlantAndEquipment"],
    "rd_expense": ["dart_ResearchAndDevelopmentExpense",
                   "ifrs-full_ResearchAndDevelopmentExpense"],
}
# Korean-caption fallback, needed because account_id is literally
# "-표준계정코드 미사용-" ("standard code not used") for many filers.
CAPTIONS = {
    "total_revenue": ["수익(매출액)", "영업수익", "매출액", "매출"],
    "cogs": ["매출원가", "영업비용"],
    "gross_profit": ["매출총이익"],
    "operating_income": ["영업이익(손실)", "영업이익"],
    "net_income": ["당기순이익(손실)", "당기순이익", "연결당기순이익"],
    "total_assets": ["자산총계"],
    "total_liabilities": ["부채총계"],
    "shareholders_equity": ["자본총계"],
    "cash_and_equivalents": ["현금및현금성자산"],
    "capex": ["유형자산의취득", "유형자산의증가"],
    "rd_expense": ["연구개발비", "경상연구개발비"],
}
# Substring matching crosses fields ("매출총이익" contains "매출"), so a caption
# containing any deny token is disqualified for that field.
DENY = {
    "total_revenue": ["이익", "원가", "비용"],
    "cogs": ["이익", "매출액", "수익"],
    "gross_profit": ["원가", "영업이익", "순이익"],
    "operating_income": ["매출총이익", "순이익", "영업수익", "영업비용"],
    "net_income": ["매출", "영업이익", "총이익"],
    "total_assets": ["부채", "자본", "유동"],
    "total_liabilities": ["자산", "자본", "유동"],
    "shareholders_equity": ["자산", "부채"],
    "cash_and_equivalents": ["제한", "유입", "유출"],
    "capex": ["처분", "감가", "손상"],
    "rd_expense": ["자산", "상각"],
}
FATAL = {"010": "unregistered key", "011": "unusable key", "012": "IP not allowed",
         "020": "daily request limit exceeded - rerun tomorrow; cache resumes"}

log = logging.getLogger("dart")


def _cacheable(r):
    """
    Cache only genuine answers. DART returns errors (quota exceeded, bad key)
    as HTTP 200 with an error status in the body; caching those would replay
    the error forever, so a quota-interrupted run could never resume.
    """
    if r.status_code != 200:
        return False
    if ".json" in r.url:
        try:
            return r.json().get("status") in ("000", "013")   # data, or "no data"
        except ValueError:
            return False
    return r.content[:2] == b"PK"      # corpCode.xml must be a real ZIP


class Dart:
    def __init__(self, key, rate_limit=RATE_LIMIT, cache=CACHE_NAME):
        # ignored_parameters keeps the API key out of cache keys and the sqlite file
        self.s = requests_cache.CachedSession(
            cache or "dart_mem", backend="sqlite" if cache else "memory",
            expire_after=None, ignored_parameters=["crtfc_key"], filter_fn=_cacheable)
        self.s.mount("https://", HTTPAdapter(max_retries=Retry(
            total=4, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])))
        self.key, self.rate_limit, self.calls = key, rate_limit, 0
        # The one place the script can go silent is inside a single call: urllib3
        # retries and backs off quietly, for minutes in the worst case. A daemon
        # thread watches the call in flight and says so when one runs long.
        self.in_flight = None          # (endpoint, start time) while a call is running
        threading.Thread(target=self._watchdog, daemon=True).start()

    def _watchdog(self):
        last_job, warned_at = None, 0.0
        while True:
            time.sleep(5)
            job = self.in_flight
            if job is not last_job:
                last_job, warned_at = job, 0.0
            if job is None:
                continue
            waited = time.monotonic() - job[1]
            if waited >= STALL_WARN_SECONDS and waited - warned_at >= STALL_WARN_SECONDS:
                warned_at = waited
                log.warning("still waiting on DART (%s) after %.0fs - the server is slow "
                            "or the call is being retried; the script has not frozen",
                            job[0], waited)

    def get(self, endpoint, **params):
        self.in_flight = (endpoint, time.monotonic())
        try:
            r = self.s.get(f"{API}/{endpoint}",
                           params={"crtfc_key": self.key, **params}, timeout=60)
        finally:
            self.in_flight = None
        if not getattr(r, "from_cache", False):
            self.calls += 1
            time.sleep(self.rate_limit)
        r.raise_for_status()
        if endpoint.endswith(".xml"):
            return r.content
        body = r.json()
        status = body.get("status", "000")
        if status in FATAL:
            raise SystemExit(f"DART error {status}: {FATAL[status]}")
        return body if status == "000" else None   # 013 = no data, routine


def to_number(x):
    t = re.sub(r"[,\s]", "", str(x or ""))
    if t in ("", "-", "nan", "None"):
        return None
    neg = t.startswith("(") and t.endswith(")")
    try:
        v = float(t.strip("()"))
    except ValueError:
        return None
    return -v if neg else v


def fmt_secs(s):
    s = int(max(s, 0))
    return f"{s // 3600}h{s % 3600 // 60:02d}m" if s >= 3600 else f"{s // 60}m{s % 60:02d}s"


class Progress:
    """
    Plain-text status lines at least every HEARTBEAT_SECONDS. Unlike a progress
    bar these survive any console, IDE output pane, or redirected log file, and
    they carry what a bar can't: API quota used, rows kept, and an ETA.
    """

    def __init__(self, label, total, dart, every=None):
        self.label, self.total, self.dart = label, total, dart
        self.every = every or HEARTBEAT_SECONDS
        self.done, self.stats = 0, {}
        self.t0 = self.last = time.monotonic()
        self.calls0 = getattr(dart, "calls", 0)

    def tick(self, current="", **stats):
        self.done += 1
        self.stats.update(stats)
        now = time.monotonic()
        if now - self.last >= self.every or self.done == self.total:
            self.last = now
            self.report(current)

    def report(self, current=""):
        elapsed = time.monotonic() - self.t0
        rate = self.done / elapsed if elapsed else 0
        eta = fmt_secs((self.total - self.done) / rate) if rate else "?"
        calls = getattr(self.dart, "calls", 0)
        extra = "".join(f" | {k} {v:,}" for k, v in self.stats.items())
        log.info("%s %d/%d (%.0f%%)%s | API calls %d this step, %d total (%.0f%% of "
                 "daily quota) | elapsed %s, ETA %s%s", self.label, self.done, self.total,
                 100 * self.done / max(self.total, 1), extra, calls - self.calls0, calls,
                 100 * calls / DAILY_QUOTA, fmt_secs(elapsed), eta,
                 f" | at: {current}" if current else "")


def ksic_section(code):
    """KSIC industry code -> section letter (A-U), or '?' if unparseable."""
    try:
        div = int(str(code).strip()[:2])
    except ValueError:
        return "?"
    return next((s for s, (lo, hi) in KSIC_SECTIONS.items() if lo <= div <= hi), "?")


def frame_signature(sections, include_unlisted, extra_path, include_delisted=False):
    """Records how a frame was built, so a stale frame is never silently reused."""
    return (f"sections={','.join(sorted(sections)) if sections else 'all'}"
            f"|unlisted={bool(include_unlisted)}|delisted={bool(include_delisted)}"
            f"|extra={os.path.basename(extra_path or '')}")


def build_frame(dart, sections=None, include_unlisted=False, extra=(), signature="",
                include_delisted=False):
    """DART register -> frame. sections=None keeps every sector."""
    log.info("downloading the DART company register (corpCode.xml, one large "
             "file - this step has no progress bar and can take a minute)...")
    t0 = time.monotonic()
    with zipfile.ZipFile(io.BytesIO(dart.get("corpCode.xml"))) as z:
        root = ET.fromstring(z.read(z.namelist()[0]))
    reg = [{t: (el.findtext(t) or "").strip() for t in ("corp_code", "corp_name", "stock_code")}
           for el in root.findall("list")]
    log.info("DART register: %d filers (%s)", len(reg), fmt_secs(time.monotonic() - t0))

    chosen = {r["corp_code"]: r for r in reg
              if include_unlisted or len(r["stock_code"]) == 6}
    forced = set()      # --extra-firms entries: exempt from the listing filter

    # Forced additions (e.g. delisted firms). corp_code is permanent in DART,
    # so a firm that left the market is still findable by code or by name.
    if extra:
        by_code = {r["corp_code"]: r for r in reg}
        by_name = {}
        for r in reg:
            by_name.setdefault(re.sub(r"\s+", "", r["corp_name"]), []).append(r)
        added, missed = 0, []
        for item in extra:
            item = str(item).strip()
            hits = [by_code[item.zfill(8)]] if item.isdigit() and item.zfill(8) in by_code \
                else by_name.get(re.sub(r"\s+", "", item), [])
            if len(hits) == 1:
                added += hits[0]["corp_code"] not in chosen
                chosen[hits[0]["corp_code"]] = hits[0]
                forced.add(hits[0]["corp_code"])
            else:     # zero hits, or an ambiguous name shared by several filers
                missed.append(f"{item} ({'ambiguous' if hits else 'not found'})")
        log.info("extra firms: %d added, %d unresolved", added, len(missed))
        for m in missed:
            log.warning("  could not resolve extra firm: %s - use its corp_code", m)

    if include_unlisted:
        log.warning("frame covers %d filers: ~%d days of API quota for the frame "
                    "alone", len(chosen), -(-len(chosen) // DAILY_QUOTA))
    log.info("fetching company info for %d firms (one API call each, cached after "
             "the first run)", len(chosen))

    out, n_delisted = [], 0
    prog = Progress("company info", len(chosen), dart)
    for r in tqdm(list(chosen.values()), desc="company info", unit="co",
                  disable=not SHOW_BAR):
        try:
            b = dart.get("company.json", corp_code=r["corp_code"])
            if not b:
                continue
            ksic = (b.get("induty_code") or "").strip()
            section = ksic_section(ksic)
            if sections and section not in sections:
                continue
            cls = b.get("corp_cls")
            status = {"Y": "KOSPI", "K": "KOSDAQ", "N": "KONEX"}.get(cls)
            if status is None:    # corp_cls "E" = other: inferred from stock code
                status = "delisted" if len(r["stock_code"]) == 6 else "unlisted"
            if status == "delisted" and not include_delisted and r["corp_code"] not in forced:
                n_delisted += 1
                continue
            out.append({"native_id": r["corp_code"], "stock_code": r["stock_code"],
                        "company_name": (b.get("corp_name_eng") or "").strip(),
                        "company_name_local": (b.get("corp_name") or "").strip(),
                        "native_industry_code": ksic, "isic_section": section,
                        "listing_status": status,
                        "acc_mt": (b.get("acc_mt") or "12").strip(),
                        "frame_filter": signature})
        finally:     # after each firm, so the counts include it
            prog.tick(r["corp_code"], kept=len(out), delisted_dropped=n_delisted)
    frame = pd.DataFrame(out)
    if n_delisted:
        log.info("excluded %d delisted firms (use --include-delisted to keep)",
                 n_delisted)
    if len(frame):
        log.info("frame: %d firms | by status %s", len(frame),
                 frame.listing_status.value_counts().to_dict())
        log.info("       by section %s", frame.isic_section.value_counts().to_dict())
    return frame


def extract(items):
    """Line items -> our 11 fields: taxonomy id first, Korean caption second."""
    by_id, by_name = {}, {}
    for it in items:
        if it.get("sj_div") not in ("BS", "IS", "CIS", "CF"):   # IS or CIS, never both
            continue
        amt = to_number(it.get("thstrm_amount"))
        if amt is None:
            continue
        aid = (it.get("account_id") or "").strip()
        if aid and not aid.startswith("-"):
            by_id.setdefault(aid, amt)
        name = re.sub(r"\s+", "", it.get("account_nm") or "")
        if name:
            by_name.setdefault(name, amt)

    v = {}
    for f in VARS:
        v[f] = next((by_id[a] for a in ACCOUNT_IDS[f] if a in by_id), None)
        if v[f] is None:
            ok = {n: a for n, a in by_name.items() if not any(d in n for d in DENY[f])}
            for cap in CAPTIONS[f]:
                hit = cap if cap in ok else next((n for n in ok if cap in n), None)
                if hit:
                    v[f] = ok[hit]
                    break

    # derive gaps from identities; never overwrite a reported value
    if v["gross_profit"] is None and None not in (v["total_revenue"], v["cogs"]):
        v["gross_profit"] = v["total_revenue"] - v["cogs"]
    if v["cogs"] is None and None not in (v["total_revenue"], v["gross_profit"]):
        v["cogs"] = v["total_revenue"] - v["gross_profit"]
    if v["total_liabilities"] is None and None not in (v["total_assets"], v["shareholders_equity"]):
        v["total_liabilities"] = v["total_assets"] - v["shareholders_equity"]
    if v["capex"] is not None:
        v["capex"] = abs(v["capex"])
    return v


def check(v, tol=0.01):
    close = lambda a, b: abs(a - b) <= tol * max(abs(a), abs(b), 1)
    bad = []
    if None not in (v["total_assets"], v["total_liabilities"], v["shareholders_equity"]) and \
            not close(v["total_assets"], v["total_liabilities"] + v["shareholders_equity"]):
        bad.append("A!=L+E")
    if None not in (v["total_revenue"], v["cogs"], v["gross_profit"]) and \
            not close(v["gross_profit"], v["total_revenue"] - v["cogs"]):
        bad.append("GP!=REV-COGS")
    return ";".join(bad) or "ok"


def collect(dart, frame, start, end, ofs_fallback=True, checkpoint=None):
    """
    One firm at a time, all requested years per firm. Every CHECKPOINT_EVERY
    firms the rows gathered so far are written to `checkpoint`, so results
    appear on disk during the run. On Ctrl+C the rows so far are returned
    rather than lost; df.attrs["interrupted"] tells the caller.
    """
    rows, firms = [], frame.to_dict("records")
    counts = {"rows": 0, "fallback_ofs": 0, "no_filing": 0, "no_core_fields": 0}
    prog = Progress("financials", len(firms), dart)
    interrupted = False
    try:
        for i, firm in enumerate(tqdm(firms, desc="financials", unit="co",
                                      disable=not SHOW_BAR), 1):
            # English name in status lines: Korean text can break some Windows consoles
            label = firm.get("company_name") or firm["native_id"]
            acc_mt = int(firm.get("acc_mt") or 12)
            for year in range(start, end + 1):
                basis, body = "consolidated", dart.get(
                    "fnlttSinglAcntAll.json", corp_code=firm["native_id"],
                    bsns_year=str(year), reprt_code="11011", fs_div="CFS")
                if not body and ofs_fallback:
                    basis, body = "separate_no_cfs", dart.get(
                        "fnlttSinglAcntAll.json", corp_code=firm["native_id"],
                        bsns_year=str(year), reprt_code="11011", fs_div="OFS")
                if not body:
                    counts["no_filing"] += 1
                    log.debug("%s %s FY%d: no annual statements", firm["native_id"],
                              label, year)
                    continue
                items = body.get("list", [])
                v = extract(items)
                if all(v[k] is None for k in ("total_revenue", "net_income", "total_assets")):
                    counts["no_core_fields"] += 1
                    log.debug("%s FY%d: no core fields extracted", firm["native_id"], year)
                    continue
                counts["fallback_ofs"] += basis == "separate_no_cfs"
                # period end from the filer's fiscal month; Compustat FY rule, as in EDGAR
                pe = (pd.Timestamp(year=year, month=acc_mt, day=1)
                      + pd.offsets.MonthEnd(0)).date()
                rows.append({
                    **{k: firm.get(k, "") for k in ("native_id", "stock_code", "company_name",
                       "company_name_local", "listing_status", "native_industry_code",
                       "isic_section")},
                    "country": "KR", "exchange": "KRX", "isin": "",
                    "fiscal_year": pe.year if pe.month >= 6 else pe.year - 1,
                    "period_end": pe, "consolidation_basis": basis,
                    "accounting_standard": "K-IFRS",
                    "currency": next((i["currency"] for i in items if i.get("currency")), "KRW"),
                    "unit_scale": 1, **v, "identity_check": check(v),
                    "missing_fields": ";".join(k for k in VARS if v[k] is None),
                    "rcept_no": items[0].get("rcept_no", "") if items else ""})
                counts["rows"] += 1
            prog.tick(label, **counts)
            if checkpoint and i % CHECKPOINT_EVERY == 0:
                pd.DataFrame(rows, columns=FIELDS).to_csv(checkpoint, index=False)
                log.info("checkpoint: %d rows saved to %s", len(rows), checkpoint)
    except KeyboardInterrupt:
        interrupted = True
        log.warning("interrupted after %d of %d firms - keeping the %d rows collected",
                    prog.done, len(firms), len(rows))
    df = pd.DataFrame(rows, columns=FIELDS)
    df.attrs.update(interrupted=interrupted, counts=counts)
    return df


def main(argv=None):
    global SHOW_BAR, HEARTBEAT_SECONDS
    p = argparse.ArgumentParser(description="Korean firm-year financials from DART.")
    p.add_argument("--dart-key", default=os.environ.get("DART_KEY"),
                   help="or set the DART_KEY environment variable")
    p.add_argument("--start-year", type=int, default=2020)
    p.add_argument("--end-year", type=int, default=2024)
    p.add_argument("--sectors", default="all",
                   help="'all' (default), 'manufacturing', or ISIC/KSIC section "
                        "letters such as C or C,G")
    p.add_argument("--frame", default=FRAME_PATH,
                   help="reused if it exists AND was built with the same settings")
    p.add_argument("--output", default=PANEL_PATH)
    p.add_argument("--frame-only", action="store_true", help="build the frame and stop")
    p.add_argument("--include-delisted", action="store_true",
                   help="keep firms no longer listed (tagged delisted)")
    p.add_argument("--include-unlisted", action="store_true",
                   help="every DART filer (~100k) - days of quota; see header")
    p.add_argument("--extra-firms",
                   help="CSV with a corp_code or corp_name column, forced into the "
                        "frame (e.g. delisted firms from KRX KIND)")
    p.add_argument("--no-ofs-fallback", action="store_true",
                   help="consolidated only; drop firms that file separate statements only")
    p.add_argument("--limit", type=int, help="first N firms only (for testing)")
    p.add_argument("--rate-limit", type=float, default=RATE_LIMIT)
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--no-bar", action="store_true",
                   help="hide progress bars (status lines still print); use if bars "
                        "render badly in your console")
    p.add_argument("--heartbeat", type=int, default=HEARTBEAT_SECONDS,
                   help="seconds between status lines")
    p.add_argument("--verbose", action="store_true",
                   help="log every firm-year, including ones with no filing")
    args = p.parse_args(argv)
    # Some Windows consoles and redirected logs cannot encode Korean; replace
    # unencodable characters instead of raising mid-run.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        datefmt="%H:%M:%S",
                        format="%(asctime)s %(levelname)-7s %(message)s")
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests_cache").setLevel(logging.WARNING)
    SHOW_BAR, HEARTBEAT_SECONDS = not args.no_bar, max(args.heartbeat, 1)
    # route log lines through tqdm so status messages print above the bar
    with logging_redirect_tqdm():
        return run(args, p)


def run(args, p):
    if not args.dart_key:
        p.error("--dart-key or DART_KEY required (free at opendart.fss.or.kr)")

    s = args.sectors.strip().lower()
    sections = (None if s == "all" else {"C"} if s == "manufacturing"
                else {x.strip().upper() for x in s.split(",") if x.strip()})
    if sections and not sections <= set(KSIC_SECTIONS):
        p.error(f"unknown section(s) {sorted(sections - set(KSIC_SECTIONS))}; "
                f"valid: {''.join(KSIC_SECTIONS)}")

    extra = []
    if args.extra_firms:
        ef = pd.read_csv(args.extra_firms, dtype=str).rename(columns=str.lower)
        col = "corp_code" if "corp_code" in ef else "corp_name" if "corp_name" in ef else None
        if col is None:
            p.error("--extra-firms CSV needs a corp_code or corp_name column")
        extra = ef[col].dropna().tolist()

    dart = Dart(args.dart_key, args.rate_limit, None if args.no_cache else CACHE_NAME)
    sig = frame_signature(sections, args.include_unlisted, args.extra_firms,
                          args.include_delisted)

    # Reuse a frame only if it was built with these exact settings. A frame
    # from an earlier manufacturing-only run would otherwise be picked up
    # silently and quietly restrict "all firms" to manufacturing.
    frame = None
    if os.path.exists(args.frame) and not args.frame_only:
        old = pd.read_csv(args.frame, dtype=str)
        if "frame_filter" in old and len(old) and (old.frame_filter == sig).all():
            frame = old
            log.info("reusing frame %s (%d firms, %s)", args.frame, len(frame), sig)
        else:
            built = old.frame_filter.iloc[0] if "frame_filter" in old and len(old) \
                else "an earlier version of this script"
            os.replace(args.frame, args.frame + ".bak")
            log.warning("existing frame was built with different settings (%s); "
                        "moved to %s.bak and rebuilding for %s", built, args.frame, sig)
    if frame is None:
        log.info("=== step 1 of 2: building the firm list (frame) ===")
        try:
            frame = build_frame(dart, sections, args.include_unlisted, extra, sig,
                                args.include_delisted)
        except KeyboardInterrupt:
            # a partial frame must never be saved: its settings signature would
            # match, so the next run would silently reuse an incomplete list
            log.warning("interrupted while building the frame; nothing saved. "
                        "Rerun the same command - calls already made are cached.")
            return 130
        if frame.empty:
            log.error("empty frame; nothing to collect")
            return 1
        frame.to_csv(args.frame, index=False)
        log.info("wrote frame -> %s", args.frame)
        if args.frame_only:
            return 0

    if args.limit:
        frame = frame.head(args.limit)
    n_years = args.end_year - args.start_year + 1
    est_calls = int(len(frame) * n_years * 1.3)   # ~30% need the OFS fallback
    log.info("=== step 2 of 2: financials for %d firms x %d year(s) ===",
             len(frame), n_years)
    log.info("expect up to ~%d API calls (~%.0f%% of daily quota), roughly %s at "
             "the current rate; cached calls are instant, so reruns are faster",
             est_calls, 100 * est_calls / DAILY_QUOTA,
             fmt_secs(est_calls * (args.rate_limit + 0.25)))
    log.info("status every %ds; partial results saved to %s every %d firms",
             HEARTBEAT_SECONDS, args.output, CHECKPOINT_EVERY)
    panel = collect(dart, frame, args.start_year, args.end_year,
                    not args.no_ofs_fallback, checkpoint=args.output)
    panel.to_csv(args.output, index=False)
    if panel.attrs.get("interrupted"):
        log.warning("partial results (%d firm-years) saved to %s. Rerun the same "
                    "command to finish - completed calls are cached and replay "
                    "instantly.", len(panel), args.output)
        return 130
    counts = panel.attrs.get("counts", {})
    log.info("=== done === firm-years with no filing: %d | no core fields: %d",
             counts.get("no_filing", 0), counts.get("no_core_fields", 0))
    if panel.empty:
        log.warning("no rows collected - check the year range and your key")
        return 1
    flagged = (panel.identity_check != "ok").sum()
    log.info("wrote %d firm-years (%d firms) -> %s", len(panel),
             panel.native_id.nunique(), args.output)
    log.info("basis: %s", panel.consolidation_basis.value_counts().to_dict())
    log.info("by section: %s", panel.isic_section.value_counts().to_dict())
    log.info("identity checks: %d ok, %d flagged; %d uncached API calls",
             len(panel) - flagged, flagged, dart.calls)
    return 0


if __name__ == "__main__":
    sys.exit(main())