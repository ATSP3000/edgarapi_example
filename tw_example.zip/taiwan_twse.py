#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# taiwan_twse.py - every firm-level variable TWSE publishes for listed firms
#
# SETUP
#   pip install requests            (no pandas; no API key)
#
# HOW TO RUN
#   python tw_twse_financials.py                      # everything, ~1 minute
#   python tw_twse_financials.py --statements-only    # just the statements, ~15 s
#   python tw_twse_financials.py --ascii-columns      # Stata-safe column names
#   python tw_twse_financials.py --sectors manufacturing
#
# OUTPUT  (folder tw_YYYYMMDD/)
#   panel.csv       the 11 harmonized variables, same columns as the Korea
#                   script so the two can be stacked
#   wide.csv        one row per firm, EVERY field from every endpoint that has
#                   one row per firm, prefixed by source block (IS|, BS|, MREV|...)
#   long/*.csv      endpoints with many rows per firm (insider transfers, daily
#                   announcements, dividends, directors' holdings...), one file each
#   dictionary.csv  every column: source endpoint, original Chinese name, English
#                   translation where provided, units hint, how many firms have it
#   raw/*.json      TWSE's responses exactly as served. KEEP THIS FOLDER: the API
#                   only ever holds the latest period, so it is your only copy.
#
# READ BEFORE USING
#   * Latest period only - no history from this API.
#   * Blocks describe DIFFERENT periods: statements are quarterly, monthly revenue
#     is the latest month, ESG is the latest report year. Every block keeps its own
#     period columns (年度/季別, 資料年月, 報告年度) - check them before combining.
#   * Units vary by field and are often in the field name (仟元 = NT$ thousands,
#     百萬元 = NT$ millions, 元 = NT$). Statement units are measured against the
#     profitability endpoint, which states millions explicitly; see panel.csv's
#     unit_scale and the log.
#   * English translations cover the register, general-industry statements,
#     monthly revenue, profitability, EPS and ESG supply-chain fields. Everything
#     else keeps its Chinese name, with the endpoint described in English.
#   * TWSE main board only; TPEx (OTC) firms are a separate system.
# -----------------------------------------------------------------------------

import argparse, calendar, csv, json, logging, math, os, re, ssl, statistics, sys, time
from datetime import date
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ============================ ADJUST THESE ===================================
BASE = "https://openapi.twse.com.tw/v1/opendata"
USER_AGENT = "academic-research-dataset (contact: you@example.edu)"
PAUSE = 0.5                          # seconds between requests
# =============================================================================

TEMPLATES = {"ci": "general industry", "fh": "financial holding", "basi": "bank",
             "bd": "securities & futures", "ins": "insurance", "mim": "other"}

# (endpoint, block code, English label, shape). "wide" endpoints are merged one
# row per firm; if one turns out to have several rows per firm it is moved to
# long/ automatically. Statement endpoints (t187ap06/07) are handled separately.
ENDPOINTS = [
    ("t187ap03_L", "REG", "Company register", "wide"),
    ("t187ap05_L", "MREV", "Monthly revenue, latest month", "wide"),
    ("t187ap17_L", "PROFIT", "Profitability ratios", "wide"),
    ("t187ap14_L", "EPS", "EPS and income summary", "wide"),
    ("t187ap15_L", "FCST", "Financial forecast achievement", "wide"),
    ("t187ap29_A_L", "DIRPAY", "Director remuneration", "wide"),
    ("t187ap29_B_L", "SUPPAY", "Supervisor remuneration", "wide"),
    ("t187ap29_C_L", "DIRPAYC", "Director remuneration, consolidated basis", "wide"),
    ("t187ap29_D_L", "SUPPAYC", "Supervisor remuneration, consolidated basis", "wide"),
    ("t187ap30_L", "INDEPDIR", "Independent directors' concurrent posts", "wide"),
    ("t187ap31_L", "FSACK", "Financial report acknowledged by supervisors", "wide"),
    ("t187ap33_L", "CHAIRCEO", "Chairman also serves as CEO", "wide"),
    ("t187ap46_L_1", "ESG01", "ESG: greenhouse gas emissions", "wide"),
    ("t187ap46_L_2", "ESG02", "ESG: energy management", "wide"),
    ("t187ap46_L_3", "ESG03", "ESG: water management", "wide"),
    ("t187ap46_L_4", "ESG04", "ESG: waste management", "wide"),
    ("t187ap46_L_5", "ESG05", "ESG: human capital development", "wide"),
    ("t187ap46_L_6", "ESG06", "ESG: board of directors", "wide"),
    ("t187ap46_L_7", "ESG07", "ESG: investor communication", "wide"),
    ("t187ap46_L_8", "ESG08", "ESG: climate-related issues", "wide"),
    ("t187ap46_L_9", "ESG09", "ESG: functional committees", "wide"),
    ("t187ap46_L_10", "ESG10", "ESG: fuel management", "wide"),
    ("t187ap46_L_11", "ESG11", "ESG: product lifecycle", "wide"),
    ("t187ap46_L_12", "ESG12", "ESG: food safety", "wide"),
    ("t187ap46_L_13", "ESG13", "ESG: supply chain management", "wide"),
    ("t187ap46_L_14", "ESG14", "ESG: product quality and safety", "wide"),
    ("t187ap46_L_15", "ESG15", "ESG: community relations", "wide"),
    ("t187ap46_L_16", "ESG16", "ESG: information security", "wide"),
    ("t187ap46_L_17", "ESG17", "ESG: inclusive finance", "wide"),
    ("t187ap46_L_18", "ESG18", "ESG: shareholding and control", "wide"),
    ("t187ap46_L_19", "ESG19", "ESG: risk management policy", "wide"),
    ("t187ap46_L_20", "ESG20", "ESG: anti-competitive behaviour litigation", "wide"),
    ("t187ap02_L", "MAJ10", "Shareholders holding over 10%", "long"),
    ("t187ap04_L", "NEWS", "Daily material announcements", "long"),
    ("t187ap08_L", "DIRSHORT", "Directors' holdings below legal minimum", "long"),
    ("t187ap11_L", "DIRHOLD", "Directors' and supervisors' holdings, by person", "long"),
    ("t187ap12_L", "INSXFER", "Insider share transfers, pre-reported", "long"),
    ("t187ap13_L", "INSNOXFER", "Insider transfers pre-reported but not executed", "long"),
    ("t187ap16_L", "FCSTVAR", "Audited results vs forecast, large variances", "long"),
    ("t187ap22_L", "SANCTION", "FSC sanctions", "long"),
    ("t187ap23_L", "DISCVIOL", "Disclosure rule violations", "long"),
    ("t187ap24_L", "CTRLCHG", "Change of control", "long"),
    ("t187ap25_L", "SCOPECHG", "Major change in business scope", "long"),
    ("t187ap26_L", "CTRLSUSP", "Control and scope change, trading suspended", "long"),
    ("t187ap27_L", "CTRLRECL", "Control and scope change, reclassified", "long"),
    ("t187ap32_L", "GOVRULES", "Corporate governance rules adopted", "long"),
    ("t187ap34_L", "BOARDELEC", "Board election methods and results", "long"),
    ("t187ap35_L", "SHPROP", "Shareholder proposals", "long"),
    ("t187ap38_L", "AGMNOTICE", "Shareholder meeting notices", "long"),
    ("t187ap41_L", "AGMINFO", "Shareholder meeting dates, venues, e-voting", "long"),
    ("t187ap45_L", "DIVIDEND", "Dividend distributions", "long"),
]
CORE = {"t187ap03_L"}                     # plus all statement endpoints
STATEMENTS_ONLY = {"t187ap03_L", "t187ap17_L"}   # 17 = units anchor
CODE_KEYS = ("公司代號", "股票代號", "證券代號")
DROP_FROM_BLOCKS = set(CODE_KEYS) | {"公司名稱"}  # repeated in every block

# English names. Metadata fields first, then block-specific.
EN_COMMON = {"出表日期": "report_date", "年度": "roc_year", "季別": "quarter",
             "資料年月": "data_year_month", "報告年度": "report_year",
             "產業別": "industry_code", "備註": "notes"}
EN = {
    "REG": {"公司簡稱": "short_name", "外國企業註冊地國": "foreign_registration_country",
            "住址": "address", "營利事業統一編號": "business_tax_id", "董事長": "chairman",
            "總經理": "general_manager", "發言人": "spokesperson",
            "發言人職稱": "spokesperson_title", "代理發言人": "deputy_spokesperson",
            "總機電話": "phone", "成立日期": "incorporation_date", "上市日期": "listing_date",
            "普通股每股面額": "par_value_per_share", "實收資本額": "paid_in_capital",
            "私募股數": "private_placement_shares", "特別股": "preferred_shares",
            "編制財務報表類型": "fs_type", "股票過戶機構": "transfer_agent",
            "過戶電話": "transfer_agent_phone", "過戶地址": "transfer_agent_address",
            "簽證會計師事務所": "audit_firm", "簽證會計師1": "auditor_1",
            "簽證會計師2": "auditor_2", "英文簡稱": "english_short_name",
            "英文通訊地址": "english_address", "傳真機號碼": "fax",
            "電子郵件信箱": "email", "網址": "website",
            "已發行普通股數或TDR原股發行股數": "common_shares_issued"},
    "IS": {"營業收入": "operating_revenue", "營業成本": "operating_costs",
           "原始認列生物資產及農產品之利益（損失）": "gain_initial_recog_bio_assets",
           "生物資產當期公允價值減出售成本之變動利益（損失）": "gain_fv_change_bio_assets",
           "營業毛利（毛損）": "gross_profit",
           "未實現銷貨（損）益": "unrealized_intercompany_profit",
           "已實現銷貨（損）益": "realized_intercompany_profit",
           "營業毛利（毛損）淨額": "gross_profit_net", "營業費用": "operating_expenses",
           "其他收益及費損淨額": "other_gains_losses_net",
           "營業利益（損失）": "operating_income",
           "營業外收入及支出": "non_operating_income_expense",
           "稅前淨利（淨損）": "pretax_income", "所得稅費用（利益）": "income_tax_expense",
           "繼續營業單位本期淨利（淨損）": "income_continuing_ops",
           "停業單位損益": "income_discontinued_ops",
           "合併前非屬共同控制股權損益": "premerger_noncommon_control_income",
           "本期淨利（淨損）": "net_income", "其他綜合損益（淨額）": "other_comprehensive_income",
           "合併前非屬共同控制股權綜合損益淨額": "premerger_noncommon_control_oci",
           "本期綜合損益總額": "total_comprehensive_income",
           "淨利（淨損）歸屬於母公司業主": "net_income_to_parent",
           "淨利（淨損）歸屬於共同控制下前手權益": "net_income_to_predecessor",
           "淨利（淨損）歸屬於非控制權益": "net_income_to_nci",
           "綜合損益總額歸屬於母公司業主": "total_ci_to_parent",
           "綜合損益總額歸屬於共同控制下前手權益": "total_ci_to_predecessor",
           "綜合損益總額歸屬於非控制權益": "total_ci_to_nci",
           "基本每股盈餘（元）": "basic_eps_ntd"},
    "BS": {"流動資產": "current_assets", "非流動資產": "noncurrent_assets",
           "資產總額": "total_assets", "流動負債": "current_liabilities",
           "非流動負債": "noncurrent_liabilities", "負債總額": "total_liabilities",
           "股本": "share_capital", "權益─具證券性質之虛擬通貨": "equity_security_tokens",
           "資本公積": "capital_surplus", "保留盈餘": "retained_earnings",
           "其他權益": "other_equity", "庫藏股票": "treasury_stock",
           "歸屬於母公司業主之權益合計": "equity_to_parent",
           "共同控制下前手權益": "predecessor_equity",
           "合併前非屬共同控制股權": "premerger_noncommon_control_equity",
           "非控制權益": "noncontrolling_interest", "權益總額": "total_equity",
           "預收股款（權益項下）之約當發行股數": "shares_equiv_advance_receipts",
           "待註銷股本股數": "shares_pending_cancellation",
           "母公司暨子公司所持有之母公司庫藏股股數": "treasury_shares_held_by_group",
           "每股參考淨值": "book_value_per_share"},
    "MREV": {"營業收入-當月營收": "revenue_month", "營業收入-上月營收": "revenue_prev_month",
             "營業收入-去年當月營收": "revenue_same_month_last_year",
             "營業收入-上月比較增減(%)": "revenue_mom_pct",
             "營業收入-去年同月增減(%)": "revenue_yoy_pct",
             "累計營業收入-當月累計營收": "revenue_ytd",
             "累計營業收入-去年累計營收": "revenue_ytd_last_year",
             "累計營業收入-前期比較增減(%)": "revenue_ytd_change_pct"},
    "PROFIT": {"營業收入(百萬元)": "revenue_ntd_mn",
               "毛利率(%)(營業毛利)/(營業收入)": "gross_margin_pct",
               "營業利益率(%)(營業利益)/(營業收入)": "operating_margin_pct",
               "稅前純益率(%)(稅前純益)/(營業收入)": "pretax_margin_pct",
               "稅後純益率(%)(稅後純益)/(營業收入)": "net_margin_pct"},
    "EPS": {"基本每股盈餘(元)": "basic_eps_ntd", "普通股每股面額": "par_value",
            "營業收入": "operating_revenue", "營業利益": "operating_income",
            "營業外收入及支出": "non_operating_income_expense", "稅後淨利": "net_income"},
    "ESG13": {"採購符合國際認可之產品責任標準者占整體採購之百分比，並依標準區分":
                  "pct_procurement_meeting_intl_standards",
              "對供應商進行稽核之家數(家)": "suppliers_audited_count",
              "對供應商進行稽核之百分比": "suppliers_audited_pct"},
}

# --- harmonized panel (unchanged from the statements-only version) -----------
VARS = ["total_revenue", "cogs", "gross_profit", "operating_income", "net_income",
        "total_assets", "total_liabilities", "shareholders_equity",
        "cash_and_equivalents", "capex", "rd_expense"]
LADDERS = {
    "total_revenue": ["營業收入", "收入", "收益", "淨收益"],
    "cogs": ["營業成本"],
    "gross_profit": ["營業毛利（毛損）", "營業毛利（毛損）淨額"],
    "operating_income": ["營業利益（損失）", "營業利益"],
    "net_income": ["本期淨利（淨損）", "本期稅後淨利（淨損）"],
    "total_assets": ["資產總額", "資產總計"],
    "total_liabilities": ["負債總額", "負債總計"],
    "shareholders_equity": ["權益總額", "權益總計"],
    "cash_and_equivalents": ["現金及約當現金"],
    "capex": [], "rd_expense": [],
}
PANEL_FIELDS = ["country", "exchange", "native_id", "stock_code", "isin", "company_name",
                "company_name_local", "fiscal_year", "period_end", "consolidation_basis",
                "accounting_standard", "currency", "unit_scale", "listing_status",
                "native_industry_code", "isic_section", *VARS, "identity_check",
                "missing_fields", "rcept_no", "quarter", "report_date", "tax_id",
                "foreign_registration_country", "statement_template", "fs_type_raw"]
TW_INDUSTRY = {
    "01": "C", "02": "C", "03": "C", "04": "C", "05": "C", "06": "C", "08": "C",
    "09": "C", "10": "C", "11": "C", "12": "C", "14": "F", "15": "H", "16": "I",
    "17": "K", "18": "G", "20": "?", "21": "C", "22": "C", "23": "D", "24": "C",
    "25": "C", "26": "C", "27": "C", "28": "C", "29": "G", "30": "J", "31": "C",
    "32": "R", "33": "A", "34": "G", "35": "?", "36": "J", "37": "?", "38": "?",
}

log = logging.getLogger("twse")


class CompatibleTLS(HTTPAdapter):
    """Relax only Python 3.13+'s strict X.509 flag, which TWSE's certificate
    trips; chain and hostname verification stay on."""

    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
        kwargs["ssl_context"] = ctx
        return super().init_poolmanager(*args, **kwargs)


def make_session(insecure=False):
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
    s.mount("https://", CompatibleTLS(max_retries=Retry(
        total=4, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])))
    if insecure:
        s.verify = False
        requests.packages.urllib3.disable_warnings()
        log.warning("TLS verification DISABLED (--insecure).")
    return s


class Fetcher:
    def __init__(self, session, raw_dir, total):
        self.s, self.raw_dir, self.total, self.n = session, raw_dir, total, 0

    def get(self, endpoint, label):
        self.n += 1
        t0 = time.monotonic()
        r = self.s.get(f"{BASE}/{endpoint}", timeout=60)
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list):
            raise ValueError(f"expected a list, got {type(data).__name__}")
        with open(os.path.join(self.raw_dir, f"{endpoint}.json"), "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        log.info("[%2d/%d] %-15s %5d rows  %4.1fs  %s", self.n, self.total, endpoint,
                 len(data), time.monotonic() - t0, label)
        time.sleep(PAUSE)
        return data


# --- value handling -----------------------------------------------------------
_COMMA_NUM = re.compile(r"\(?-?\d{1,3}(,\d{3})+(\.\d+)?\)?")


def to_number(x):
    t = str(x if x is not None else "").replace(",", "").strip()
    if t in ("", "-", "--", "N/A"):
        return None
    neg = t.startswith("(") and t.endswith(")")
    try:
        v = float(t.strip("()"))
    except ValueError:
        return None
    return -v if neg else v


def clean(v):
    """Strip thousands separators from numbers like '1,234' or '(1,234)'. Anything
    else - IDs, tax numbers, ROC dates, zero-padded codes - is left exactly as served."""
    s = "" if v is None else str(v).strip()
    if _COMMA_NUM.fullmatch(s):
        n = to_number(s)
        return str(int(n)) if n is not None and n.is_integer() else repr(n)
    return s


def code_of(rec):
    return next((str(rec[k]).strip() for k in CODE_KEYS if rec.get(k)), "")


def units_hint(field):
    for token, hint in (("百萬元", "NT$ millions"), ("仟元", "NT$ thousands"),
                        ("千元", "NT$ thousands"), ("(元/股)", "NT$ per share"),
                        ("（元）", "NT$"), ("(元)", "NT$"), ("(%)", "percent"),
                        ("百分比", "percent"), ("(股)", "shares"), ("股數", "shares"),
                        ("(家)", "count"), ("(人)", "persons")):
        if token in field:
            return hint
    return ""


def ascii_name(block, field, idx, used):
    en = EN.get(block, {}).get(field) or EN_COMMON.get(field)
    base = f"{block.lower()}_{en}" if en else f"{block.lower()}_f{idx:03d}"
    base = re.sub(r"[^a-z0-9_]", "_", base.lower())[:32]
    name, k = base, 2
    while name in used:                                   # Stata: unique, <=32 chars
        suffix = f"_{k}"
        name, k = base[:32 - len(suffix)] + suffix, k + 1
    used.add(name)
    return name


# --- harmonized panel helpers -------------------------------------------------
def roc_date(s):
    s = str(s or "").strip()
    if not s.isdigit() or len(s) < 6:
        return None
    try:
        return date(int(s[:-4]) + 1911, int(s[-4:-2]), int(s[-2:]))
    except ValueError:
        return None


def quarter_end(roc_year, season):
    y, q = int(roc_year) + 1911, int(season)
    return date(y, 3 * q, calendar.monthrange(y, 3 * q)[1])


def check(v, tol=0.01):
    close = lambda a, b: abs(a - b) <= tol * max(abs(a), abs(b), 1)
    bad = []
    if None not in (v["total_assets"], v["total_liabilities"], v["shareholders_equity"]) and \
            not close(v["total_assets"], v["total_liabilities"] + v["shareholders_equity"]):
        bad.append("A!=L+E")
    if None not in (v["total_revenue"], v["cogs"], v["gross_profit"]) and \
            not close(v["gross_profit"], v["total_revenue"] - v["cogs"]):
        bad.append("GP!=REV-COGS")
    return ";".join(bad) or "ok"


def basis_from(raw):
    raw = str(raw or "").strip()
    return ("consolidated" if "合併" in raw else "separate" if "個別" in raw
            else f"unknown({raw})" if raw else "")


def infer_unit_scale(panel_rows, profit):
    """
    Measure statement units against t187ap17, whose revenue field is labelled
    NT$ millions. ratio = statement revenue / (millions x 1e6): ~1 means NT$,
    ~0.001 means NT$ thousands. Falls back to median total assets if needed.
    """
    ratios = []
    for r in panel_rows:
        p = profit.get(r["native_id"])
        mn = to_number(p.get("營業收入(百萬元)")) if p else None
        if r["total_revenue"] and mn and mn > 10:        # skip tiny, rounding-dominated
            ratios.append(r["total_revenue"] / (mn * 1e6))
    if len(ratios) >= 10:
        med = statistics.median(ratios)
        exp = round(math.log10(med)) if med > 0 else None
        if exp in (0, -3) and abs(math.log10(med) - exp) < 0.2:
            scale = 1 if exp == 0 else 1000
            log.info("units measured against the NT$-millions profitability table "
                     "(%d firms, median ratio %.4g) -> statements are in %s",
                     len(ratios), med, "NT$" if scale == 1 else "NT$ thousands")
            if abs(med * scale - 1) > 0.05:
                log.warning("ratio is not ~1 after scaling (%.3f): the two tables may "
                            "cover different periods (quarter vs year-to-date)", med * scale)
            return scale
        log.warning("unit measurement inconclusive (median ratio %.4g)", med)
    assets = [r["total_assets"] for r in panel_rows if r.get("total_assets")]
    if len(assets) < 20:
        log.warning("too few firms to infer units; assuming NT$ thousands")
        return 1000
    med = statistics.median(assets)
    scale = 1000 if med < 1e9 else 1
    log.info("units inferred from median total assets (%s) -> %s", f"{med:,.0f}",
             "NT$ thousands" if scale == 1000 else "NT$")
    return scale


# --- main collection ----------------------------------------------------------
def run(fetcher, endpoints, sections, out_dir, ascii_cols, unit_override):
    # 1. statements: 6 templates x income/balance, merged per firm
    income, balance, is_fields, bs_fields, field_templates = {}, {}, [], [], {}
    for t in TEMPLATES:
        for kind, store, order in (("06", income, is_fields), ("07", balance, bs_fields)):
            recs = fetcher.get(f"t187ap{kind}_L_{t}",
                               f"{'Income statement' if kind == '06' else 'Balance sheet'}"
                               f" ({TEMPLATES[t]})")
            blk = "IS" if kind == "06" else "BS"
            for rec in recs:
                store[code_of(rec)] = (t, rec)
                for f in rec:
                    if f not in order:
                        order.append(f)
                    field_templates.setdefault((blk, f), set()).add(t)

    # 2. every other endpoint
    wide, long_, failed, labels = {}, {}, [], {}
    for ep, block, label, shape in endpoints:
        labels[block] = (ep, label)
        try:
            recs = fetcher.get(ep, label)
        except Exception as e:                            # noqa: BLE001
            if ep in CORE:
                raise
            log.warning("  %s failed (%s) - skipped, run continues", ep, e)
            failed.append(ep)
            continue
        codes = [code_of(r) for r in recs]
        dup = len(codes) != len(set(codes))
        if shape == "wide" and dup:
            log.warning("  %s has several rows per firm - written to long/ instead", ep)
        if shape == "long" or dup:
            long_[block] = (ep, label, recs)
        else:
            wide[block] = {c: r for c, r in zip(codes, recs) if c}

    register = wide.get("REG", {})
    profit = wide.get("PROFIT", {})     # units anchor; empty if it failed

    # 3. firm universe and sector filter
    universe = sorted((set(income) | set(balance) | set(register)) - {""})
    def section_of(code):
        ind = str(register.get(code, {}).get("產業別", "")).strip()
        ind = ind.zfill(2) if ind.isdigit() else ind
        return ind, TW_INDUSTRY.get(ind, "?")
    if sections:
        universe = [c for c in universe if section_of(c)[1] in sections]
    keep = set(universe)

    # 4. harmonized panel
    panel = []
    for code in universe:
        t_inc, inc = income.get(code, (None, None))
        t_bal, bal = balance.get(code, (None, None))
        src = inc or bal
        if not src:
            continue
        try:
            pe = quarter_end(src["年度"], src["季別"])
        except (KeyError, ValueError, TypeError):
            continue
        merged = {**(bal or {}), **(inc or {})}
        v = {f: next((to_number(merged[k]) for k in LADDERS[f]
                      if to_number(merged.get(k)) is not None), None) for f in VARS}
        reg = register.get(code, {})
        ind, section = section_of(code)
        foreign = str(reg.get("外國企業註冊地國", "")).strip()
        rd = roc_date(src.get("出表日期"))
        panel.append({
            "country": "TW", "exchange": "TWSE", "native_id": code, "stock_code": code,
            "isin": "", "company_name": str(reg.get("英文簡稱", "")).strip(),
            "company_name_local": str(src.get("公司名稱") or reg.get("公司名稱", "")).strip(),
            "fiscal_year": pe.year, "period_end": pe.isoformat(),
            "consolidation_basis": basis_from(reg.get("編制財務報表類型")),
            "accounting_standard": "TIFRS", "currency": "TWD", "unit_scale": "",
            "listing_status": "TWSE", "native_industry_code": ind, "isic_section": section,
            **v, "identity_check": check(v),
            "missing_fields": ";".join(k for k in VARS if v[k] is None), "rcept_no": "",
            "quarter": f"Q{int(src['季別'])}", "report_date": rd.isoformat() if rd else "",
            "tax_id": str(reg.get("營利事業統一編號", "")).strip(),
            "foreign_registration_country": "" if foreign in ("", "-", "－") else foreign,
            "statement_template": t_inc or t_bal,
            "fs_type_raw": str(reg.get("編制財務報表類型", "")).strip()})
    scale = infer_unit_scale(panel, profit) if unit_override == "auto" else int(unit_override)
    for r in panel:
        r["unit_scale"] = scale

    # 5. wide table: blocks in a fixed order, each block's own fields
    blocks = [("REG", register, None)]
    blocks += [("IS", {c: r for c, (t, r) in income.items()}, is_fields),
               ("BS", {c: r for c, (t, r) in balance.items()}, bs_fields)]
    blocks += [(b, wide[b], None) for _, b, _, _ in endpoints if b in wide and b != "REG"]
    columns, dictionary, used = [], [], set()
    for block, recs, order in blocks:
        fields = order or []
        if not order:
            for r in recs.values():
                for f in r:
                    if f not in fields:
                        fields.append(f)
        fields = [f for f in fields if f not in DROP_FROM_BLOCKS]
        if block in ("IS", "BS"):
            ep, label = ((f"t187ap06_L_{{{",".join(TEMPLATES)}}}", "Income statement")
                         if block == "IS" else
                         (f"t187ap07_L_{{{",".join(TEMPLATES)}}}", "Balance sheet"))
        else:
            ep, label = labels[block]
        for i, f in enumerate(fields, 1):
            col_ascii, col_zh = ascii_name(block, f, i, used), f"{block}|{f}"
            col = col_ascii if ascii_cols else col_zh
            n = sum(1 for c in keep if str(recs.get(c, {}).get(f, "")).strip() not in ("", "-"))
            columns.append((col, block, recs, f))
            dictionary.append({
                "column": col_zh, "ascii_column": col_ascii, "block": block,
                "file": "wide.csv", "endpoint": ep,
                "endpoint_label_en": label, "field_zh": f,
                "field_en": EN.get(block, {}).get(f) or EN_COMMON.get(f, ""),
                "units_hint": units_hint(f) or ("see unit_scale in panel.csv"
                                                if block in ("IS", "BS") else ""),
                "templates": ",".join(sorted(field_templates.get((block, f), []))),
                "firms_with_value": n})

    id_cols = ["native_id", "company_name", "company_name_local", "statement_template",
               "isic_section"]
    by_code = {r["native_id"]: r for r in panel}
    with open(os.path.join(out_dir, "wide.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(id_cols + [c for c, *_ in columns])
        for code in universe:
            p = by_code.get(code, {})
            reg = register.get(code, {})
            ident = [code, str(reg.get("英文簡稱", "")).strip(),
                     str(reg.get("公司名稱", "") or p.get("company_name_local", "")).strip(),
                     p.get("statement_template", ""), section_of(code)[1]]
            w.writerow(ident + [clean(recs.get(code, {}).get(f)) for _, _, recs, f in columns])

    # 6. long files
    os.makedirs(os.path.join(out_dir, "long"), exist_ok=True)
    for block, (ep, label, recs) in long_.items():
        recs = [r for r in recs if not sections or code_of(r) in keep]
        fields = []
        for r in recs:
            for f in r:
                if f not in fields:
                    fields.append(f)
        path = os.path.join(out_dir, "long", f"{block}_{ep}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["native_id"] + fields)
            for r in recs:
                w.writerow([code_of(r)] + [clean(r.get(f)) for f in fields])
        for f in fields:
            dictionary.append({"column": f, "ascii_column": "", "block": block,
                               "file": f"long/{block}_{ep}.csv",
                               "endpoint": ep, "endpoint_label_en": label, "field_zh": f,
                               "field_en": EN_COMMON.get(f, ""), "units_hint": units_hint(f),
                               "templates": "", "firms_with_value": len({code_of(r) for r in recs
                                                                         if r.get(f)})})

    # 7. panel + dictionary
    with open(os.path.join(out_dir, "panel.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=PANEL_FIELDS)
        w.writeheader()
        w.writerows(panel)
    with open(os.path.join(out_dir, "dictionary.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(dictionary[0]))
        w.writeheader()
        w.writerows(dictionary)

    # 8. report
    periods = {}
    for r in panel:
        periods[f"{r['fiscal_year']}{r['quarter']}"] = periods.get(f"{r['fiscal_year']}{r['quarter']}", 0) + 1
    log.info("=" * 70)
    log.info("firms: %d | panel rows: %d | statement periods: %s", len(universe), len(panel), periods)
    log.info("wide.csv: %d columns from %d blocks | long/: %d files | dictionary: %d entries",
             len(columns) + len(id_cols), len(blocks), len(long_), len(dictionary))
    if failed:
        log.warning("endpoints that failed and were skipped: %s", ", ".join(failed))
    tsmc = by_code.get("2330")
    if tsmc:
        f = lambda x: f"NT${x * scale / 1e9:,.1f} bn" if x is not None else "n/a"
        log.info("SANITY CHECK - TSMC %s %s: revenue %s | net income %s | assets %s",
                 tsmc["fiscal_year"], tsmc["quarter"], f(tsmc["total_revenue"]),
                 f(tsmc["net_income"]), f(tsmc["total_assets"]))
        log.info("  compare with TSMC's published report: single-quarter or year-to-date?")
    return panel, columns, long_, failed


def main(argv=None):
    p = argparse.ArgumentParser(description="Every firm-level variable TWSE publishes.")
    p.add_argument("--sectors", default="all",
                   help="'all', 'manufacturing', or ISIC section letters e.g. C or C,G")
    p.add_argument("--out-dir", help="default: tw_<today>")
    p.add_argument("--statements-only", action="store_true",
                   help="register + statements only (~15 requests)")
    p.add_argument("--ascii-columns", action="store_true",
                   help="Stata-safe column names in wide.csv (mapping in dictionary.csv)")
    p.add_argument("--unit-scale", choices=("auto", "1", "1000"), default="auto")
    p.add_argument("--insecure", action="store_true", help="last resort for TLS errors")
    args = p.parse_args(argv)

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    logging.basicConfig(level=logging.INFO, datefmt="%H:%M:%S",
                        format="%(asctime)s %(levelname)-7s %(message)s")

    s = args.sectors.strip().lower()
    sections = (None if s == "all" else {"C"} if s == "manufacturing"
                else {x.strip().upper() for x in s.split(",") if x.strip()})
    out_dir = args.out_dir or f"tw_{date.today():%Y%m%d}"
    raw_dir = os.path.join(out_dir, "raw")
    os.makedirs(raw_dir, exist_ok=True)

    endpoints = [e for e in ENDPOINTS if not args.statements_only or e[0] in STATEMENTS_ONLY]
    total = 12 + len(endpoints)
    log.info("fetching %d TWSE endpoints -> %s (about %ds)", total, out_dir, int(total * 0.8))
    try:
        run(Fetcher(make_session(args.insecure), raw_dir, total), endpoints, sections,
            out_dir, args.ascii_columns, args.unit_scale)
    except requests.exceptions.SSLError as e:
        log.error("TLS error connecting to TWSE: %s\nRetry with --insecure.", e)
        return 2
    except requests.exceptions.RequestException as e:
        log.error("could not reach TWSE: %s", e)
        return 2
    log.info("done -> %s", out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())