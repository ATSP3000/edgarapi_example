#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# uk_companies_house.py - UK firm-year financials from Companies House
#
# SETUP
#   pip install requests requests-cache tqdm
#   Free API key: https://developer.company-information.service.gov.uk -> create
#   an application -> "live" key. Put it in the CH_KEY environment variable.
#
# HOW TO RUN
#   set CH_KEY=your-key                      (Windows)   /  export CH_KEY=...   (mac/Linux)
#   python uk_companies_house.py --companies my_companies.csv --start-year 2020 --end-year 2024
#
# NARROWING THE SAMPLE (see --help)
#   --listed-only          keep only plc companies (proxy for listed; most
#                          plcs are NOT listed, and foreign-incorporated LSE
#                          issuers are not on the register at all)
#   --full-accounts-only   keep only filers of full/group accounts - the ones
#                          that include a profit and loss account. This is the
#                          filter that removes most data gaps.
#   --min-v2-fields N      drop Panel V2 rows with fewer than N fields present
#   For an exact listed sample, supply the company numbers via --companies.
#
# INPUT - pick one
#   --companies FILE.csv   a CSV with a company_number column (8 chars, keep the
#                          leading zeros: "00225951"). RECOMMENDED. Companies
#                          House has no "is listed" flag, so a listed-only sample
#                          must come from a list you supply (e.g. the LSE's own
#                          list of companies, matched to company numbers).
#   --sic-codes 25620,28410
#                          build the sample from Companies House advanced search.
#                          Search results are capped (~10k per query), so this
#                          suits narrow SIC codes, not "all manufacturing".
#   --from-bulk FILE.csv   the free monthly "Company Data Product" snapshot
#                          (download.companieshouse.gov.uk). Best route for large
#                          populations: it is one download and costs no API calls.
#                          Combine with --sic-codes to filter it.
#
# OUTPUT (same shape as the Korea script, so panels can be stacked)
#   frame_uk.csv        one row per company: name, SIC codes, status, type
#   panel_uk.csv        one row per firm-year, the 11 harmonized variables, GBP
#   facts_long_uk.csv   every tagged fact of every filing, nothing dropped,
#                       including dimensional (segment/breakdown) facts
#   wide_uk.csv         one row per firm-year x every element reported by at
#                       least 1% of firm-years (--wide-min-share)
#   dictionary_uk.csv   every wide column: element name, English label, coverage
#   panel_v2_uk.csv     the Version 2 field list, same column names as the US
#                       Panel V2 so the two stack; missing values written as NA
#   coverage_v2_uk.csv  per V2 field: which UK elements were used, how often they
#                       were found, and what each UK mapping does differently
#
# WHAT YOU WILL AND WILL NOT GET  (read this before interpreting empty columns)
#   Small companies may file "filleted" accounts - a balance sheet and notes with
#   NO profit and loss account. In a sample of ten real filings taken from
#   Companies House bulk data, none contained turnover or profit. So for small
#   firms expect total_assets/equity/cash and empty revenue, cogs, operating
#   income and net income. This is the public record, not a parsing failure.
#   The reform that would have required small companies to file a P&L from April
#   2027 was paused in January 2026, so plan for the gap to persist.
#
#   UK GAAP (FRS 102/105) balance sheets follow the Companies Act formats, which
#   have no "total assets" line at all. total_assets is therefore DERIVED as
#   fixed assets + current assets, and total_liabilities as assets - equity.
#   The derived_fields column records which values were computed this way.
#
#   Cash flow statements are not required for small entities, so capex is usually
#   absent. R&D expense is rarely tagged outside full accounts.
# -----------------------------------------------------------------------------

import argparse, csv, difflib, functools, logging, math, os, re, sys, time
import xml.etree.ElementTree as ET
from datetime import date, datetime
import requests, requests_cache
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from tqdm import tqdm

# ============================ ADJUST THESE ===================================
API = "https://api.company-information.service.gov.uk"
# Companies House allows 600 requests per 5 minutes (7,200/hour). 0.55s between
# requests is ~545 per 5 minutes: comfortably inside it. The client also reads
# the X-Ratelimit-* headers and waits when the window is nearly spent.
RATE_LIMIT = 0.55
CACHE_NAME = "ch_cache"
FRAME_PATH, PANEL_PATH = "frame_uk.csv", "panel_uk.csv"
LONG_PATH, WIDE_PATH, DICT_PATH = "facts_long_uk.csv", "wide_uk.csv", "dictionary_uk.csv"
HEARTBEAT_SECONDS, CHECKPOINT_EVERY = 20, 100
# =============================================================================

VARS = ["total_revenue", "cogs", "gross_profit", "operating_income", "net_income",
        "total_assets", "total_liabilities", "shareholders_equity",
        "cash_and_equivalents", "capex", "rd_expense"]
PANEL_FIELDS = ["country", "exchange", "native_id", "stock_code", "isin", "company_name",
                "company_name_local", "fiscal_year", "period_end", "consolidation_basis",
                "accounting_standard", "currency", "unit_scale", "listing_status",
                "native_industry_code", "isic_section", *VARS, "identity_check",
                "missing_fields", "rcept_no", "made_up_date", "filing_date",
                "transaction_id", "taxonomy", "derived_fields", "facts_in_filing"]
LONG_FIELDS = ["native_id", "fiscal_year", "period_end", "transaction_id", "element",
               "element_label_en", "prefix", "context_ref", "dimensional", "members",
               "start_date", "end_date", "kind", "value", "unit", "decimals", "scale", "sign"]

# Element-name ladders. The UK GAAP names are taken from the UK Department for
# Business and Trade's own Companies House accounts parser (uktrade/
# stream-read-xbrl), so they reflect what filings actually contain; the IFRS
# names cover companies filing under UK-adopted IFRS. Matching is on the LOCAL
# name only - prefixes vary by filing software (core:, uk-core:, ns5:...).
LADDERS = {
    "total_revenue": ["TurnoverGrossOperatingRevenue", "TurnoverRevenue", "Revenue",
                      "RevenueFromContractsWithCustomers", "RevenueFromSaleOfGoods"],
    "cogs": ["CostSales", "CostOfSales"],
    "gross_profit": ["GrossProfitLoss", "GrossProfit"],
    "operating_income": ["OperatingProfitLoss", "ProfitLossFromOperatingActivities"],
    "net_income": ["ProfitLoss", "ProfitLossForPeriod",
                   "ProfitLossAttributableToOwnersOfParent"],
    "total_assets": ["Assets", "TotalAssets"],          # IFRS only; else derived
    "total_liabilities": ["Liabilities", "TotalLiabilities"],   # IFRS only; else derived
    "shareholders_equity": ["Equity", "ShareholderFunds",
                            "NetAssetsLiabilitiesIncludingPensionAssetLiability",
                            "NetAssetsLiabilities"],
    "cash_and_equivalents": ["CashBankInHand", "CashBankOnHand", "CashAndCashEquivalents"],
    "capex": ["PurchaseOfPropertyPlantEquipment",
              "PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities",
              "PaymentsToAcquirePropertyPlantEquipment"],
    "rd_expense": ["ResearchDevelopmentExpense", "ResearchAndDevelopmentExpense"],
}
# Used only to reconstruct the totals the Companies Act formats omit. Fixed
# assets are tried three ways: the summary line; then total-assets-less-current-
# liabilities minus net current assets; then by summing the components, because
# many filers tag only PropertyPlantEquipment.
DERIVE_HELPERS = {
    "fixed_assets": ["FixedAssets", "TotalFixedAssets"],
    "current_assets": ["CurrentAssets"],
    "talcl": ["TotalAssetsLessCurrentLiabilities"],
    "net_current": ["NetCurrentAssetsLiabilities"],
    "ppe": ["PropertyPlantEquipment", "TangibleFixedAssets"],
    "intangible": ["IntangibleAssets", "IntangibleAssetsOtherThanGoodwill", "Goodwill"],
    "investments": ["InvestmentsFixedAssets", "InvestmentsInGroupUndertakingsParticipatingInterests"],
}
NULL_MARKERS = {"", "-", "\u2013", "\u2014", "\u2212"}   # hyphen, en dash, em dash, minus
IX_LOCAL = {"nonFraction"}
EXCEL_MAX_COLUMNS = 16384

log = logging.getLogger("ch")


# =============================================================================
# HTTP client
# =============================================================================
def _cacheable(r):
    return r.status_code == 200


class CH:
    """Companies House client: basic auth, rate-limit aware, cached."""

    def __init__(self, key, rate_limit=RATE_LIMIT, cache=CACHE_NAME):
        self.s = requests_cache.CachedSession(
            cache or "ch_mem", backend="sqlite" if cache else "memory",
            expire_after=None, filter_fn=_cacheable)
        self.s.auth = (key, "")           # API key as username, empty password
        self.s.headers.update({"Accept": "application/json"})
        self.s.mount("https://", HTTPAdapter(max_retries=Retry(
            total=4, backoff_factor=2, status_forcelist=[500, 502, 503, 504],
            allowed_methods=["GET"])))
        self.rate_limit, self.calls = rate_limit, 0

    def get(self, url, accept=None, tolerate=(), **params):
        """tolerate: status codes returned as None instead of raising."""
        headers = {"Accept": accept} if accept else None
        for attempt in range(6):
            r = self.s.get(url if url.startswith("http") else f"{API}{url}",
                           params=params or None, headers=headers, timeout=60)
            if not getattr(r, "from_cache", False):
                self.calls += 1
                time.sleep(self.rate_limit)
            if r.status_code == 401:
                raise SystemExit("Companies House rejected the API key (401). Check CH_KEY "
                                 "and that you created a LIVE key, not a test key.")
            if r.status_code == 403:
                raise SystemExit("Companies House returned 403. The key may be suspended "
                                 "for exceeding the rate limit; wait and retry.")
            if r.status_code == 404 or r.status_code in tolerate:
                return None
            if r.status_code == 429:
                wait = self._reset_wait(r)
                log.warning("rate limited; waiting %.0fs", wait)
                time.sleep(wait)
                continue
            r.raise_for_status()
            self._respect_headers(r)
            return r
        log.error("giving up after repeated rate limiting: %s", url)
        return None

    @staticmethod
    def _reset_wait(r):
        try:
            return max(1.0, float(r.headers.get("X-Ratelimit-Reset", 0)) - time.time()) + 1
        except (TypeError, ValueError):
            return 30.0

    def _respect_headers(self, r):
        """Pause before the window is exhausted rather than after."""
        try:
            remaining = int(r.headers["X-Ratelimit-Remain"])
        except (KeyError, TypeError, ValueError):
            return
        if remaining <= 5:
            wait = self._reset_wait(r)
            log.info("rate-limit window nearly spent (%d left); pausing %.0fs",
                     remaining, wait)
            time.sleep(wait)

    def json(self, url, **params):
        r = self.get(url, **params)
        if r is None:
            return None
        try:
            return r.json()
        except ValueError:
            log.error("non-JSON response from %s", url)
            return None


# =============================================================================
# Small helpers
# =============================================================================
def fmt_secs(s):
    s = int(max(s, 0))
    return f"{s // 3600}h{s % 3600 // 60:02d}m" if s >= 3600 else f"{s // 60}m{s % 60:02d}s"


def parse_date(text):
    try:
        return datetime.strptime(str(text)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def fiscal_year_for(period_end):
    """Same Compustat rule as the other scripts, so panels can be pooled."""
    return period_end.year if period_end.month >= 6 else period_end.year - 1


def normalize_number(number):
    """Company numbers are 8 characters and may be zero-padded or prefixed
    (SC..., NI..., OC...). Keep letters, pad digits."""
    t = str(number or "").strip().upper().replace(" ", "")
    if not t:
        return ""
    m = re.fullmatch(r"([A-Z]*)(\d+)", t)
    return f"{m.group(1)}{m.group(2).zfill(8 - len(m.group(1)))}" if m else t


@functools.lru_cache(maxsize=None)
def label_of(element):
    """TurnoverGrossOperatingRevenue -> 'Turnover gross operating revenue'."""
    words = re.sub(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ", element).split()
    if not words:
        return ""
    words = [w if w.isupper() and len(w) > 1 else w.lower() for w in words]
    s = " ".join(words)
    for a, b in (("profit loss", "profit (loss)"), ("assets liabilities", "assets (liabilities)"),
                 ("gain loss", "gain (loss)"), ("income expense", "income (expense)")):
        s = re.sub(rf"\b{a}\b", b, s)
    return s[:1].upper() + s[1:]


def num_str(v):
    return "" if v is None else str(int(v)) if float(v).is_integer() else repr(v)


# =============================================================================
# iXBRL parsing
# =============================================================================
def parse_value(element, text):
    """
    Apply the inline-XBRL numeric conventions: sign="-" negates, scale multiplies
    by a power of ten, and the format attribute decides the separators
    (numcommadot = 1,234.56; numdotcomma = 1.234,56; numspacedot = 1 234.56).
    """
    text = (text or "").strip()
    if text in NULL_MARKERS:
        return None
    fmt = (element.get("format") or "").rpartition(":")[2].lower()
    if fmt == "numdotcomma":
        cleaned = text.replace(".", "").replace(",", ".")
    elif fmt in ("numspacedot", "numspacecomma"):
        cleaned = text.replace(" ", "").replace("\xa0", "")
        if fmt == "numspacecomma":
            cleaned = cleaned.replace(",", ".")
    else:
        cleaned = text.replace(",", "")
    cleaned = cleaned.replace("\xa0", "").replace("(", "-").replace(")", "").strip()
    if cleaned in NULL_MARKERS:
        return None
    try:
        value = float(cleaned)
    except ValueError:
        return None
    try:
        value *= 10 ** int(element.get("scale") or 0)
    except ValueError:
        pass
    return -value if (element.get("sign") or "") == "-" else value


def parse_ixbrl(content):
    """
    Return (facts, taxonomy) from an iXBRL/XBRL accounts document.
    Each fact: element, prefix, context_ref, dimensional, start, end, kind,
    value, unit, decimals, scale, sign.
    Facts on contexts carrying dimensions (segment/scenario members) are kept
    but flagged: they are breakdowns, not the headline figures.
    """
    try:
        root = ET.fromstring(content)
    except ET.ParseError as exc:
        log.debug("XML parse error: %s", exc)
        return [], ""
    contexts = {}
    for ctx in root.iter():
        if not ctx.tag.endswith("}context"):
            continue
        cid = ctx.get("id")
        start = end = None
        kind = ""
        for node in ctx.iter():
            if node.tag.endswith("}instant"):
                start = end = (node.text or "").strip()
                kind = "instant"
            elif node.tag.endswith("}startDate"):
                start = (node.text or "").strip()
                kind = "duration"
            elif node.tag.endswith("}endDate"):
                end = (node.text or "").strip()
        members = [(n.text or "").split(":")[-1].strip() for n in ctx.iter()
                   if n.tag.endswith("}explicitMember")]
        members += ["typed" for n in ctx.iter() if n.tag.endswith("}typedMember")]
        contexts[cid] = (start, end, kind, bool(members), ";".join(members))

    taxonomy = ";".join(sorted({v for v in (root.attrib.get("xmlns"),) if v} |
                               {u for u in re.findall(r"xbrl\.frc\.org\.uk/[^\"' ]+", content
                                                      .decode("utf-8", "replace")
                                                      if isinstance(content, bytes) else content)}))
    facts = []
    for el in root.iter():
        local = el.tag.rpartition("}")[2]
        name = el.get("name")
        if local in IX_LOCAL and name:                 # inline XBRL
            element, prefix = name.rpartition(":")[2], name.rpartition(":")[0]
            text = "".join(el.itertext())
        elif name is None and el.get("contextRef") and el.get("unitRef"):
            element, prefix = local, el.tag[1:].rpartition("}")[0]   # plain XBRL instance
            text = el.text or ""
        else:
            continue
        ctx = contexts.get(el.get("contextRef"), (None, None, "", False, ""))
        value = parse_value(el, text)
        if value is None:
            continue
        facts.append({"element": element, "prefix": prefix, "context_ref": el.get("contextRef", ""),
                      "dimensional": ctx[3], "members": ctx[4],
                      "start_date": ctx[0] or "", "end_date": ctx[1] or "",
                      "kind": ctx[2], "value": value, "unit": el.get("unitRef", ""),
                      "decimals": el.get("decimals", ""), "scale": el.get("scale", ""),
                      "sign": el.get("sign", "")})
    return facts, taxonomy


def pick(facts, names, period_end, kind, tolerance=7):
    """First element in the ladder with a non-dimensional fact for this period."""
    for name in names:
        best = None
        for f in facts:
            if f["element"] != name or f["dimensional"] or f["kind"] != kind:
                continue
            end = parse_date(f["end_date"])
            if end is None or abs((end - period_end).days) > tolerance:
                continue
            if kind == "duration":
                start = parse_date(f["start_date"])
                if start is None or not 300 <= (end - start).days <= 430:
                    continue
            if best is None or abs(f["value"]) > abs(best):
                best = f["value"]
        if best is not None:
            return best
    return None


def fixed_assets_of(facts, period_end):
    """(value, how) - three routes, most reliable first."""
    direct = pick(facts, DERIVE_HELPERS["fixed_assets"], period_end, "instant")
    if direct is not None:
        return direct, "FixedAssets"
    talcl = pick(facts, DERIVE_HELPERS["talcl"], period_end, "instant")
    net_current = pick(facts, DERIVE_HELPERS["net_current"], period_end, "instant")
    if None not in (talcl, net_current):
        return talcl - net_current, "TALCL-netcurrent"
    parts = [(k, pick(facts, DERIVE_HELPERS[k], period_end, "instant"))
             for k in ("ppe", "intangible", "investments")]
    present = [(k, v) for k, v in parts if v is not None]
    if present:
        return sum(v for _, v in present), "sum(" + "+".join(k for k, _ in present) + ")"
    return None, ""


def extract(facts, period_end):
    v = {f: pick(facts, LADDERS[f], period_end,
                 "instant" if f in ("total_assets", "total_liabilities",
                                    "shareholders_equity", "cash_and_equivalents")
                 else "duration") for f in VARS}
    derived = []
    # The Companies Act balance-sheet formats have no total-assets line, so build it.
    if v["total_assets"] is None:
        fixed, how = fixed_assets_of(facts, period_end)
        current = pick(facts, DERIVE_HELPERS["current_assets"], period_end, "instant")
        if fixed is not None or current is not None:
            v["total_assets"] = (fixed or 0) + (current or 0)
            derived.append(f"total_assets={how or 'none'}+current_assets")
    if v["total_liabilities"] is None and None not in (v["total_assets"], v["shareholders_equity"]):
        v["total_liabilities"] = v["total_assets"] - v["shareholders_equity"]
        derived.append("total_liabilities=assets-equity")
    if v["gross_profit"] is None and None not in (v["total_revenue"], v["cogs"]):
        v["gross_profit"] = v["total_revenue"] - v["cogs"]
        derived.append("gross_profit=revenue-cogs")
    if v["cogs"] is None and None not in (v["total_revenue"], v["gross_profit"]):
        v["cogs"] = v["total_revenue"] - v["gross_profit"]
        derived.append("cogs=revenue-gross_profit")
    if v["capex"] is not None:
        v["capex"] = abs(v["capex"])
    return v, derived


def check(v, derived=(), tol=0.01):
    """
    Accounting checks. Note which values were DERIVED: if liabilities were
    computed as assets minus equity, then A = L + E holds by construction and
    proves nothing, so that identity is only tested on reported values. Derived
    rows are instead sanity-checked for impossible signs, which is what actually
    catches a mis-built total.
    """
    close = lambda a, b: abs(a - b) <= tol * max(abs(a), abs(b), 1)
    derived_fields = ";".join(derived)
    bad = []
    if "total_liabilities=assets-equity" not in derived_fields:
        if None not in (v["total_assets"], v["total_liabilities"], v["shareholders_equity"]) \
                and not close(v["total_assets"], v["total_liabilities"] + v["shareholders_equity"]):
            bad.append("A!=L+E")
    else:
        bad.append("A=L+E not tested (liabilities derived)")
    if "gross_profit=revenue-cogs" not in derived_fields and \
            "cogs=revenue-gross_profit" not in derived_fields:
        if None not in (v["total_revenue"], v["cogs"], v["gross_profit"]) and \
                not close(v["gross_profit"], v["total_revenue"] - v["cogs"]):
            bad.append("GP!=REV-COGS")
    if v["total_assets"] is not None and v["total_assets"] < 0:
        bad.append("ASSETS<0")
    if v["total_liabilities"] is not None and v["total_liabilities"] < 0:
        bad.append("LIABILITIES<0")         # usually means total assets was under-built
    if v["total_revenue"] is not None and v["total_revenue"] < 0:
        bad.append("REVENUE<0")
    return ";".join(bad) or "ok"


# =============================================================================
# Panel V2 - the same field list as the US Version 2 panel, mapped to UK elements
# =============================================================================
# Column names match sec_panel_v2.py so the two panels line up. Three structural
# differences from us-gaap drive the mapping:
#   1. UK filings have no separate machinery/land elements. Components are the
#      SAME PP&E element tagged with a PropertyPlantEquipmentClassesDimension
#      member (LandBuildings, PlantMachinery, ComputerEquipment...), so those
#      fields are read from DIMENSIONAL facts via "member".
#   2. Small entities file no cash flow statement, so payments to acquire PP&E
#      usually do not exist. The additions line from the fixed-asset note is
#      offered as a proxy and flagged in "proxies_used" - additions are not cash
#      paid, so treat them as a different measure, not a substitute.
#   3. UK filings DO tag employee numbers (AverageNumberEmployeesDuringPeriod),
#      which us-gaap filings generally do not.
# "derive" sums several elements; "note" is copied into the coverage file.
V2_FIELDS = [
    {"col": "RevenueFromContractWithCustomerExcludingAssessedTax", "kind": "duration",
     "elements": ["TurnoverRevenue", "TurnoverGrossOperatingRevenue", "Revenue"]},
    {"col": "GrossProfit", "kind": "duration", "elements": ["GrossProfitLoss", "GrossProfit"]},
    {"col": "CostOfGoodsAndServicesSold", "kind": "duration",
     "elements": ["CostSales", "CostOfSales"]},
    {"col": "OperatingExpenses", "kind": "duration", "elements": ["OperatingExpenses"],
     "derive": ["AdministrativeExpenses", "DistributionCosts", "OtherOperatingExpensesFormat2"],
     "note": "UK formats have no single operating-expenses line; derived as "
             "administrative + distribution + other operating expenses"},
    {"col": "IncreaseDecreaseInInventories", "kind": "duration",
     "elements": ["IncreaseDecreaseInInventories", "IncreaseDecreaseInStocks"],
     "note": "cash-flow line; absent from small-entity accounts"},
    {"col": "InventoryWorkInProcess", "kind": "instant",
     "elements": ["InventoriesWorkInProgress", "WorkInProgress", "TotalInventories"],
     "member": r"WorkInProgress"},
    {"col": "InventoryFinishedGoods", "kind": "instant",
     "elements": ["InventoriesFinishedGoodsGoodsForResale", "FinishedGoodsGoodsForResale",
                  "TotalInventories"],
     "member": r"FinishedGoods"},
    {"col": "EmployeeRelatedLiabilitiesCurrent", "kind": "instant",
     "elements": ["AccruedLiabilitiesDeferredIncome", "TaxationSocialSecurityPayable",
                  "OtherCreditorsAccrualsDeferredIncome"],
     "note": "no UK equivalent of the us-gaap element; nearest candidates only"},
    {"col": "InventoryRawMaterials", "kind": "instant",
     "elements": ["InventoriesRawMaterialsConsumables", "RawMaterialsConsumables",
                  "TotalInventories"],
     "member": r"RawMaterials"},
    {"col": "CostOfGoodsAndServiceExcludingDepreciationDepletionAndAmortization",
     "kind": "duration", "elements": [],
     "note": "no UK equivalent - UK GAAP does not split cost of sales ex-depreciation"},
    {"col": "CostOfGoodsAndServicesSoldDepreciation", "kind": "duration",
     "elements": ["DepreciationExpensePropertyPlantEquipment"], "member": r"CostSales",
     "note": "only where the filer tags depreciation by ExpenseTypeDimension=CostSales"},
    {"col": "SellingGeneralAndAdministrativeExpense", "kind": "duration",
     "elements": ["AdministrativeExpenses"], "derive": ["AdministrativeExpenses",
                                                        "DistributionCosts"],
     "note": "UK reports administrative and distribution separately; derived value "
             "is their sum"},
    {"col": "PropertyPlantAndEquipmentGross", "kind": "instant",
     "elements": ["PropertyPlantEquipmentGrossCost", "TangibleFixedAssetsCost"]},
    {"col": "PropertyPlantAndEquipmentNet", "kind": "instant",
     "elements": ["PropertyPlantEquipment", "TangibleFixedAssets"]},
    {"col": "AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment",
     "kind": "instant",
     "elements": ["AccumulatedDepreciationImpairmentPropertyPlantEquipment"]},
    {"col": "PaymentsToAcquirePropertyPlantAndEquipment", "kind": "duration",
     "elements": ["PurchaseOfPropertyPlantEquipment", "PurchasePropertyPlantEquipment"],
     "proxy": ["AdditionsOtherThanThroughBusinessCombinationsPropertyPlantEquipment",
               "TotalAdditionsIncludingFromBusinessCombinationsPropertyPlantEquipment"],
     "note": "cash-flow line, usually absent; proxy is additions from the fixed-asset "
             "note, which is not cash paid"},
    {"col": "CapitalLeasedAssetsGross", "kind": "instant",
     "elements": ["PropertyPlantEquipmentGrossCost", "PropertyPlantEquipment"],
     "member": r"(FinanceLease|LeasedAsset|HirePurchase)"},
    {"col": "ProceedsFromSaleOfPropertyPlantAndEquipment", "kind": "duration",
     "elements": ["ProceedsFromSalesPropertyPlantEquipment"],
     "proxy": ["DisposalsPropertyPlantEquipment"],
     "note": "proxy is disposals at cost from the fixed-asset note, not sale proceeds"},
    {"col": "MachineryAndEquipmentGross", "kind": "instant",
     "elements": ["PropertyPlantEquipmentGrossCost", "PropertyPlantEquipment"],
     "member": r"(PlantMachinery|MachineryEquipment|PlantEquipment)",
     "note": "from the PP&E classes dimension, not a separate element"},
    {"col": "Land", "kind": "instant",
     "elements": ["PropertyPlantEquipmentGrossCost", "PropertyPlantEquipment"],
     "member": r"(LandBuildings|^Land)",
     "note": "UK filings combine land AND buildings in one class; not comparable "
             "with the us-gaap Land element"},
    {"col": "TotalEmployees", "kind": "any",
     "elements": ["AverageNumberEmployeesDuringPeriod", "EmployeesTotal"],
     "note": "average during the period; UK tags this, unlike us-gaap"},
]
V2_META = ["native_id", "company_name", "fiscal_year", "period_end", "filing_date",
           "sic_primary", "transaction_id"]
V2_TAIL = ["fields_found", "proxies_used", "dimensional_used"]


def v2_pick(facts, spec, period_end, member=None):
    """Like pick(), but optionally requiring a dimension member match."""
    want = re.compile(member, re.I) if member else None
    for name in spec:
        best = None
        for f in facts:
            if f["element"] != name:
                continue
            if want is None and f["dimensional"]:
                continue
            if want is not None and not (f["dimensional"] and (
                    want.search(f.get("members", "")) or want.search(f["context_ref"]))):
                continue
            end = parse_date(f["end_date"])
            if end is None or abs((end - period_end).days) > 7:
                continue
            if best is None or abs(f["value"]) > abs(best):
                best = f["value"]
        if best is not None:
            return best, name
    return None, ""


def v2_extract(facts, period_end, na="NA"):
    """One Panel V2 row's worth of values, plus which used a proxy or a dimension."""
    out, proxies, dims, found = {}, [], [], 0
    for spec in V2_FIELDS:
        kind = spec["kind"]
        pool = [f for f in facts if kind == "any" or f["kind"] == kind]
        value, used = v2_pick(pool, spec["elements"], period_end, spec.get("member"))
        if value is not None and spec.get("member"):
            dims.append(f"{spec['col']}<-{used}[{spec['member']}]")
        if value is None and spec.get("derive"):
            parts = [(e, v2_pick(pool, [e], period_end)[0]) for e in spec["derive"]]
            present = [(e, v) for e, v in parts if v is not None]
            if present:
                value = sum(v for _, v in present)
                proxies.append(f"{spec['col']}=sum(" + "+".join(e for e, _ in present) + ")")
        if value is None and spec.get("proxy"):
            value, used = v2_pick(pool, spec["proxy"], period_end, spec.get("member"))
            if value is not None:
                proxies.append(f"{spec['col']}<-{used}")
        out[spec["col"]] = na if value is None else num_str(value)
        found += value is not None
    return out, found, proxies, dims


def write_v2(path, coverage_path, rows, na="NA"):
    columns = V2_META + [s["col"] for s in V2_FIELDS] + V2_TAIL
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, na) for c in columns})
    n = max(len(rows), 1)
    seen = set()
    for r in rows:
        seen.update(r.get("_elements", ()))
    log.info("=" * 74)
    log.info("Panel V2 coverage (%d firm-years) -> %s", len(rows), path)
    with open(coverage_path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["field", "uk_elements", "member_filter", "firm_years_with_value",
                    "share", "suggestions", "note"])
        for spec in V2_FIELDS:
            got = sum(1 for r in rows if r.get(spec["col"], na) != na)
            suggestions = ""
            if got == 0 and spec["elements"]:
                suggestions = ";".join(difflib.get_close_matches(spec["elements"][0], seen,
                                                                 n=3, cutoff=0.6))
            log.info("  %-58s %6.1f%%%s", spec["col"][:58], 100 * got / n,
                     "  <- similar present: " + suggestions if suggestions else "")
            w.writerow([spec["col"], ";".join(spec["elements"]), spec.get("member", ""),
                        got, f"{got / n:.3f}", suggestions, spec.get("note", "")])
    log.info("coverage table -> %s", coverage_path)


# =============================================================================
# Frame
# =============================================================================
def frame_from_numbers(ch, numbers):
    rows = []
    for number in tqdm(numbers, desc="company profiles", unit="co", disable=not SHOW_BAR):
        p = ch.json(f"/company/{number}")
        if not p:
            log.warning("%s: not found", number)
            continue
        rows.append(profile_row(number, p))
    return rows


def profile_row(number, p):
    sic = p.get("sic_codes") or []
    return {"native_id": number, "company_name": (p.get("company_name") or "").strip(),
            "company_status": p.get("company_status", ""), "company_type": p.get("type", ""),
            "incorporated": p.get("date_of_creation", ""),
            "sic_codes": ";".join(sic), "sic_primary": sic[0] if sic else "",
            "accounts_category": ((p.get("accounts") or {}).get("last_accounts") or {})
                                 .get("type", ""),
            "jurisdiction": p.get("jurisdiction", "")}


def frame_from_search(ch, sic_codes, size=100, cap=10000):
    rows, seen = [], set()
    for sic in sic_codes:
        start, hits = 0, None
        while True:
            body = ch.json("/advanced-search/companies", sic_codes=sic, size=size,
                           start_index=start)
            if not body:
                break
            items = body.get("items") or []
            hits = body.get("hits", hits)
            for it in items:
                number = normalize_number(it.get("company_number"))
                if number and number not in seen:
                    seen.add(number)
                    sics = it.get("sic_codes") or []
                    rows.append({"native_id": number,
                                 "company_name": (it.get("company_name") or "").strip(),
                                 "company_status": it.get("company_status", ""),
                                 "company_type": it.get("company_type", ""),
                                 "incorporated": it.get("date_of_creation", ""),
                                 "sic_codes": ";".join(sics),
                                 "sic_primary": sics[0] if sics else sic,
                                 "accounts_category": "", "jurisdiction": ""})
            start += len(items)
            if not items or start >= min(hits or 0, cap):
                break
        log.info("SIC %s: %d results (reported hits %s)", sic, start, hits)
        if hits and hits > cap:
            log.warning("SIC %s has %d companies but search returns at most ~%d. Use "
                        "--from-bulk for this population.", sic, hits, cap)
    return rows


def frame_from_bulk(path, sic_codes=None, active_only=True):
    """Companies House 'Company Data Product' monthly CSV - no API calls."""
    rows = 0
    out = []
    with open(path, encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        cols = {c.strip(): c for c in (reader.fieldnames or [])}
        num_col = next((cols[c] for c in cols if "CompanyNumber" in c), None)
        name_col = next((cols[c] for c in cols if "CompanyName" in c), None)
        if not num_col:
            raise SystemExit(f"{path} does not look like the Companies House bulk file "
                             f"(no CompanyNumber column)")
        sic_cols = [cols[c] for c in cols if c.startswith("SICCode.SicText")]
        for r in reader:
            rows += 1
            status = (r.get("CompanyStatus") or "").strip()
            if active_only and status and status != "Active":
                continue
            sics = []
            for c in sic_cols:
                text = (r.get(c) or "").strip()
                if text:
                    sics.append(text.split(" - ")[0].strip())
            if sic_codes and not any(s in sic_codes for s in sics):
                continue
            out.append({"native_id": normalize_number(r.get(num_col)),
                        "company_name": (r.get(name_col) or "").strip(),
                        "company_status": status,
                        "company_type": (r.get("CompanyCategory") or "").strip(),
                        "incorporated": (r.get("IncorporationDate") or "").strip(),
                        "sic_codes": ";".join(sics), "sic_primary": sics[0] if sics else "",
                        "accounts_category": (r.get("Accounts.AccountCategory") or "").strip(),
                        "jurisdiction": (r.get("CountryOfOrigin") or "").strip()})
    log.info("bulk file: %d companies read, %d kept", rows, len(out))
    return out


# =============================================================================
# Sample filters - narrowing to companies whose accounts actually contain data
# =============================================================================
# Companies House has NO "is listed" flag, so "listed only" cannot be read from
# the register. Two available fields get close:
#   company_type == plc     every UK-incorporated listed company is a PLC, but
#                           most PLCs are NOT listed, so this over-includes. It
#                           does remove the millions of private "ltd" companies.
#   accounts_category       full/group accounts contain a profit and loss
#                           account; small, micro-entity, filleted, dormant and
#                           total-exemption filings usually do not. This is the
#                           filter that removes data gaps.
# The only exact listed-company sample comes from a list you supply to
# --companies (e.g. the LSE's own list of companies, matched to company numbers).
LISTED_TYPES = {"plc", "public-limited-company", "old-public-company",
                "northern-ireland-other", "plc-shares"}
FULL_ACCOUNT_CATEGORIES = {"full", "group", "audited-abridged", "audit-exemption-subsidiary"}


def _norm(text):
    return re.sub(r"[^a-z0-9]+", "-", str(text or "").strip().lower()).strip("-")


def apply_filters(frame, listed_only=False, full_accounts_only=False,
                  company_types=None, accounts_categories=None):
    """Filter a frame in memory, so toggling a filter needs no rebuild."""
    types = {_norm(t) for t in (company_types or [])} or (LISTED_TYPES if listed_only else None)
    cats = ({_norm(c) for c in (accounts_categories or [])} or
            (FULL_ACCOUNT_CATEGORIES if full_accounts_only else None))
    if not types and not cats:
        return frame
    kept, dropped_type, dropped_cat, unknown_cat = [], 0, 0, 0
    for row in frame:
        if types and _norm(row.get("company_type")) not in types:
            dropped_type += 1
            continue
        if cats:
            category = _norm(row.get("accounts_category"))
            if not category:
                unknown_cat += 1            # never filed, or the bulk file had no value
                continue
            if category not in cats:
                dropped_cat += 1
                continue
        kept.append(row)
    log.info("filters: %d companies in, %d kept", len(frame), len(kept))
    if types:
        log.info("  dropped %d not of type %s", dropped_type, sorted(types)[:4])
    if cats:
        log.info("  dropped %d whose last accounts were not %s, %d with no accounts "
                 "category recorded", dropped_cat, sorted(cats)[:3], unknown_cat)
    if not kept:
        log.warning("  every company was filtered out - check the company_type and "
                    "accounts_category values in your frame file")
    return kept


# =============================================================================
# Collection
# =============================================================================
SHOW_BAR = True


class Progress:
    def __init__(self, label, total, client, every=None):
        self.label, self.total, self.client = label, total, client
        self.every = every or HEARTBEAT_SECONDS
        self.done, self.stats = 0, {}
        self.t0 = self.last = time.monotonic()

    def tick(self, current="", **stats):
        self.done += 1
        self.stats.update(stats)
        now = time.monotonic()
        if now - self.last >= self.every or self.done == self.total:
            self.last = now
            elapsed = now - self.t0
            rate = self.done / elapsed if elapsed else 0
            eta = fmt_secs((self.total - self.done) / rate) if rate else "?"
            extra = "".join(f" | {k} {v:,}" for k, v in self.stats.items())
            log.info("%s %d/%d (%.0f%%)%s | API calls %d | elapsed %s, ETA %s%s",
                     self.label, self.done, self.total, 100 * self.done / max(self.total, 1),
                     extra, self.client.calls, fmt_secs(elapsed), eta,
                     f" | at: {current}" if current else "")


def accounts_filings(ch, number, start_year, end_year):
    """{fiscal_year: filing} for accounts filings whose made-up date is in range."""
    best, start = {}, 0
    while True:
        body = ch.json(f"/company/{number}/filing-history", category="accounts",
                       items_per_page=100, start_index=start)
        if not body:
            break
        items = body.get("items") or []
        for it in items:
            made_up = parse_date((it.get("description_values") or {}).get("made_up_date"))
            if made_up is None:
                continue
            fy = fiscal_year_for(made_up)
            if not (start_year <= fy <= end_year):
                continue
            filed = parse_date(it.get("date")) or date.min
            doc = ((it.get("links") or {}).get("document_metadata"))
            record = {"made_up": made_up, "filed": filed, "doc": doc,
                      "transaction_id": it.get("transaction_id", ""),
                      "type": it.get("type", ""), "paper": bool(it.get("paper_filed"))}
            if fy not in best or filed > best[fy]["filed"]:
                best[fy] = record
        start += len(items)
        if not items or start >= body.get("total_count", 0):
            break
    return best


def fetch_accounts_document(ch, doc_url):
    """
    The accounts document as iXBRL/XBRL, or None when only a PDF exists.
    Companies House answers 406 Not Acceptable when it does not hold the
    requested format for a filing - common for older and paper-converted
    accounts - so 406 is a normal outcome here, not an error.
    """
    for accept in ("application/xhtml+xml", "application/xml"):
        r = ch.get(f"{doc_url}/content", accept=accept, tolerate=(406, 410, 415))
        if r is None:
            continue
        ctype = (r.headers.get("Content-Type") or "").lower()
        head = r.content[:600].lstrip().lower()
        if ("xhtml" in ctype or "xml" in ctype or head.startswith(b"<?xml")
                or b"<html" in head or b"xbrl" in head):
            return r.content
        log.debug("document served as %s, not iXBRL", ctype or "unknown type")
        return None
    return None


def collect(ch, frame, start_year, end_year, checkpoint=None, long_writer=None,
            v2_rows=None, na_value="NA"):
    rows, firms = [], list(frame)
    counts = {"rows": 0, "no_accounts": 0, "paper_or_no_doc": 0, "pdf_only": 0,
              "no_facts": 0, "fetch_errors": 0, "filleted": 0}
    prog = Progress("accounts", len(firms), ch)
    interrupted = False
    try:
        for i, firm in enumerate(tqdm(firms, desc="accounts", unit="co",
                                      disable=not SHOW_BAR), 1):
            number = firm["native_id"]
            filings = accounts_filings(ch, number, start_year, end_year)
            if not filings:
                counts["no_accounts"] += 1
            for fy, filing in sorted(filings.items()):
                if filing["paper"] or not filing["doc"]:
                    counts["paper_or_no_doc"] += 1
                    continue
                try:
                    content = fetch_accounts_document(ch, filing["doc"])
                except requests.RequestException as exc:
                    counts["fetch_errors"] += 1      # never end the whole run
                    log.warning("%s FY%d: document fetch failed (%s); skipped",
                                number, fy, exc)
                    continue
                if content is None:
                    counts["pdf_only"] += 1
                    continue
                facts, taxonomy = parse_ixbrl(content)
                if not facts:
                    counts["no_facts"] += 1
                    continue
                pe = filing["made_up"]
                v, derived = extract(facts, pe)
                if long_writer is not None:
                    long_writer.writerows(
                        [number, fy, pe.isoformat(), filing["transaction_id"], f["element"],
                         label_of(f["element"]), f["prefix"], f["context_ref"],
                         int(f["dimensional"]), f.get("members", ""),
                         f["start_date"], f["end_date"], f["kind"],
                         num_str(f["value"]), f["unit"], f["decimals"], f["scale"], f["sign"]]
                        for f in facts)
                if v["total_revenue"] is None and v["net_income"] is None:
                    counts["filleted"] += 1     # balance sheet only: normal for small firms
                rows.append({
                    "country": "GB", "exchange": "", "native_id": number, "stock_code": "",
                    "isin": "", "company_name": firm.get("company_name", ""),
                    "company_name_local": firm.get("company_name", ""),
                    "fiscal_year": fy, "period_end": pe.isoformat(),
                    "consolidation_basis": "", "accounting_standard": "",
                    "currency": "GBP", "unit_scale": 1,
                    "listing_status": firm.get("company_type", ""),
                    "native_industry_code": firm.get("sic_primary", ""), "isic_section": "",
                    **v, "identity_check": check(v, derived),
                    "missing_fields": ";".join(k for k in VARS if v[k] is None),
                    "rcept_no": filing["transaction_id"],
                    "made_up_date": pe.isoformat(),
                    "filing_date": filing["filed"].isoformat() if filing["filed"] != date.min else "",
                    "transaction_id": filing["transaction_id"], "taxonomy": taxonomy,
                    "derived_fields": ";".join(derived), "facts_in_filing": len(facts)})
                counts["rows"] += 1
                if v2_rows is not None:
                    v2, n_found, proxies, dims = v2_extract(facts, pe, na_value)
                    v2_rows.append({
                        "native_id": number, "company_name": firm.get("company_name", ""),
                        "fiscal_year": fy, "period_end": pe.isoformat(),
                        "filing_date": filing["filed"].isoformat()
                        if filing["filed"] != date.min else "",
                        "sic_primary": firm.get("sic_primary", ""),
                        "transaction_id": filing["transaction_id"], **v2,
                        "fields_found": n_found, "proxies_used": ";".join(proxies),
                        "dimensional_used": ";".join(dims),
                        "_elements": {f["element"] for f in facts}})
            prog.tick(number, **counts)
            if checkpoint and i % CHECKPOINT_EVERY == 0:
                write_csv(checkpoint, PANEL_FIELDS, rows)
                log.info("checkpoint: %d firm-years -> %s", len(rows), checkpoint)
    except KeyboardInterrupt:
        interrupted = True
        log.warning("interrupted after %d of %d companies - keeping %d firm-years",
                    prog.done, len(firms), len(rows))
    return rows, counts, interrupted


def write_csv(path, fieldnames, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if v is None else v) for k, v in r.items()})


# =============================================================================
# Wide + dictionary (built by streaming the long file twice, as in Korea)
# =============================================================================
def _stream(long_path):
    cur, seen = None, {}
    with open(long_path, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            fy = (r["native_id"], r["fiscal_year"])
            if fy != cur:
                cur, seen = fy, {}
            if r["dimensional"] == "1" or r["value"] == "":
                continue                      # breakdowns stay in the long file
            base = f"{r['kind'] or 'x'}|{r['element']}"
            if base in seen:
                if r["value"] in seen[base]:
                    continue
                seen[base].append(r["value"])
                key = f"{base}#{len(seen[base])}"
            else:
                seen[base], key = [r["value"]], base
            yield fy, r, key


def build_wide(long_path, wide_path, dict_path, panel_rows, min_share=0.01, ascii_cols=False):
    stats, fys = {}, set()
    for fy, r, key in _stream(long_path):
        fys.add(fy)
        s = stats.setdefault(key, {"n": 0, "element": r["element"], "kind": r["kind"],
                                   "label": r["element_label_en"]})
        s["n"] += 1
    n_fy = len(fys)
    if not n_fy:
        log.warning("no facts for a wide file")
        return
    need = max(1, math.ceil(min_share * n_fy))
    keep = sorted((k for k, s in stats.items() if s["n"] >= need),
                  key=lambda k: (stats[k]["kind"] != "instant", -stats[k]["n"], k))
    used, cols, dictionary = set(), {}, []
    for idx, k in enumerate(keep, 1):
        s = stats[k]
        occ = re.search(r"#(\d+)$", k)
        base = ("BS|" if s["kind"] == "instant" else "PL|") + (s["label"] or s["element"])
        name = base + (f" #{occ.group(1)}" if occ else "")
        while name in used:
            name += "_"
        used.add(name)
        asc = re.sub(r"[^a-z0-9]+", "_",
                     (("bs_" if s["kind"] == "instant" else "pl_") +
                      (s["label"] or s["element"])).lower())[:32].strip("_")
        a, n2 = asc, 2
        while asc in {d["ascii_column"] for d in dictionary}:
            asc, n2 = f"{a[:30]}_{n2}", n2 + 1
        cols[k] = asc if ascii_cols else name
        dictionary.append({"column": name, "ascii_column": asc,
                           "block": "Balance sheet" if s["kind"] == "instant"
                           else "Profit and loss / flows", "element": s["element"],
                           "label_en": s["label"], "firm_years_with_value": s["n"],
                           "share_of_firm_years": f"{s['n'] / n_fy:.3f}"})

    by_key = {(r["native_id"], str(r["fiscal_year"])): r for r in panel_rows}
    id_cols = ["native_id", "company_name", "fiscal_year", "period_end",
               "native_industry_code", "taxonomy"]
    idx_of = {k: i for i, k in enumerate(keep)}
    written = 0
    with open(wide_path, "w", newline="", encoding="utf-8-sig") as out:
        w = csv.writer(out)
        w.writerow(id_cols + [cols[k] for k in keep])
        cur, vals = None, None

        def flush(fy):
            p = by_key.get(fy, {})
            w.writerow([fy[0], p.get("company_name", ""), fy[1], p.get("period_end", ""),
                        p.get("native_industry_code", ""), p.get("taxonomy", "")] + vals)

        for fy, r, key in _stream(long_path):
            if fy != cur:
                if cur:
                    flush(cur)
                    written += 1
                cur, vals = fy, [""] * len(keep)
            i = idx_of.get(key)
            if i is not None:
                vals[i] = r["value"]
        if cur:
            flush(cur)
            written += 1
    write_csv(dict_path, list(dictionary[0]), dictionary)
    n_cols = len(id_cols) + len(keep)
    log.info("wide: %d firm-years x %d columns -> %s", written, n_cols, wide_path)
    log.info("  %d elements kept (>= %d firm-years); %d rarer ones remain in the long file",
             len(keep), need, len(stats) - len(keep))
    if n_cols > EXCEL_MAX_COLUMNS:
        log.warning("  %d columns exceeds Excel's limit; raise --wide-min-share", n_cols)


# =============================================================================
# CLI
# =============================================================================
def main(argv=None):
    global SHOW_BAR
    p = argparse.ArgumentParser(description="UK firm-year financials from Companies House.")
    p.add_argument("--api-key", default=os.environ.get("CH_KEY"),
                   help="or set the CH_KEY environment variable")
    src = p.add_argument_group("sample (choose one)")
    src.add_argument("--companies", help="CSV with a company_number column")
    src.add_argument("--sic-codes", help="comma-separated SIC codes for advanced search")
    src.add_argument("--from-bulk", help="Companies House monthly bulk CSV")
    p.add_argument("--start-year", type=int, default=2020)
    p.add_argument("--end-year", type=int, default=2024)
    p.add_argument("--frame", default=FRAME_PATH, help="reused if it exists")
    p.add_argument("--output", default=PANEL_PATH)
    p.add_argument("--long-output", default=LONG_PATH)
    p.add_argument("--wide-output", default=WIDE_PATH)
    p.add_argument("--dictionary-output", default=DICT_PATH)
    p.add_argument("--frame-only", action="store_true")
    p.add_argument("--no-wide", action="store_true")
    p.add_argument("--no-v2", action="store_true", help="skip the Panel V2 files")
    p.add_argument("--v2-output", default="panel_v2_uk.csv")
    p.add_argument("--v2-coverage-output", default="coverage_v2_uk.csv")
    p.add_argument("--na-value", default="NA",
                   help="Panel V2: written when a field has no data")
    p.add_argument("--wide-min-share", type=float, default=0.01)
    p.add_argument("--ascii-columns", action="store_true", help="Stata-safe column names")
    sel = p.add_argument_group("narrowing the sample (togglable)")
    sel.add_argument("--listed-only", action="store_true",
                     help="keep only public limited companies (plc). Proxy for listed: "
                          "every UK-incorporated listed company is a plc, but most plcs "
                          "are not listed")
    sel.add_argument("--full-accounts-only", action="store_true",
                     help="keep only companies whose last accounts were full or group "
                          "accounts - i.e. those that file a profit and loss account")
    sel.add_argument("--company-types", help="custom list, e.g. plc,ltd")
    sel.add_argument("--accounts-categories", help="custom list, e.g. full,group,small")
    sel.add_argument("--min-v2-fields", type=int, default=0,
                     help="drop Panel V2 rows with fewer than N of the 21 fields present")
    p.add_argument("--include-dissolved", action="store_true",
                   help="bulk frame: keep non-active companies (survivorship)")
    p.add_argument("--limit", type=int)
    p.add_argument("--rate-limit", type=float, default=RATE_LIMIT)
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--no-bar", action="store_true")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args(argv)

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        datefmt="%H:%M:%S",
                        format="%(asctime)s %(levelname)-7s %(message)s")
    SHOW_BAR = not args.no_bar
    if not args.api_key:
        p.error("--api-key or CH_KEY required (free at developer.company-information.service.gov.uk)")
    sics = [s.strip() for s in (args.sic_codes or "").split(",") if s.strip()]

    ch = CH(args.api_key, args.rate_limit, None if args.no_cache else CACHE_NAME)

    frame_cols = ["native_id", "company_name", "company_status", "company_type",
                  "incorporated", "sic_codes", "sic_primary", "accounts_category",
                  "jurisdiction"]
    if os.path.exists(args.frame) and not args.frame_only:
        with open(args.frame, encoding="utf-8-sig", newline="") as fh:
            frame = list(csv.DictReader(fh))
        log.info("reusing frame %s (%d companies)", args.frame, len(frame))
    else:
        log.info("=== step 1 of 2: building the company list ===")
        if args.from_bulk:
            frame = frame_from_bulk(args.from_bulk, set(sics) or None,
                                    not args.include_dissolved)
        elif args.companies:
            with open(args.companies, encoding="utf-8-sig", newline="") as fh:
                reader = csv.DictReader(fh)
                key = next((c for c in (reader.fieldnames or [])
                            if c.lower().replace(" ", "_") in
                            ("company_number", "companynumber", "number", "crn")), None)
                if not key:
                    p.error("--companies CSV needs a company_number column")
                numbers = [normalize_number(r[key]) for r in reader if r.get(key)]
            log.info("%d company numbers; fetching profiles (1 API call each)", len(numbers))
            frame = frame_from_numbers(ch, numbers)
        elif sics:
            frame = frame_from_search(ch, sics)
        else:
            p.error("choose a sample: --companies, --from-bulk or --sic-codes")
        if not frame:
            log.error("empty frame")
            return 1
        write_csv(args.frame, frame_cols, frame)
        log.info("wrote %d companies -> %s", len(frame), args.frame)
        if args.frame_only:
            return 0

    frame = apply_filters(frame, args.listed_only, args.full_accounts_only,
                          (args.company_types or "").split(",") if args.company_types else None,
                          (args.accounts_categories or "").split(",")
                          if args.accounts_categories else None)
    if not frame:
        log.error("no companies left after filtering")
        return 1
    if args.limit:
        frame = frame[: args.limit]
    n_years = args.end_year - args.start_year + 1
    est = len(frame) * (1 + 2 * min(n_years, 3))
    log.info("=== step 2 of 2: accounts for %d companies x %d year(s) ===",
             len(frame), n_years)
    log.info("roughly %d API calls, about %s at the current rate (600 per 5 minutes "
             "is the Companies House limit); cached calls are instant",
             est, fmt_secs(est * (args.rate_limit + 0.2)))

    long_fh = None if args.no_wide else open(args.long_output, "w", newline="",
                                             encoding="utf-8-sig")
    long_writer = None
    if long_fh:
        long_writer = csv.writer(long_fh)
        long_writer.writerow(LONG_FIELDS)
    try:
        v2_rows = None if args.no_v2 else []
        rows, counts, interrupted = collect(ch, frame, args.start_year, args.end_year,
                                            checkpoint=args.output, long_writer=long_writer,
                                            v2_rows=v2_rows, na_value=args.na_value)
    finally:
        if long_fh:
            long_fh.close()
    write_csv(args.output, PANEL_FIELDS, rows)
    if interrupted:
        if v2_rows:
            write_v2(args.v2_output, args.v2_coverage_output, v2_rows, args.na_value)
        log.warning("partial results (%d firm-years) saved to %s; rerun to finish - "
                    "completed calls are cached", len(rows), args.output)
        return 130
    if not rows:
        log.warning("no firm-years collected")
        return 1
    flagged = sum(r["identity_check"] != "ok" for r in rows)
    log.info("=== done === %d firm-years from %d companies -> %s", len(rows),
             len({r["native_id"] for r in rows}), args.output)
    log.info("companies with no accounts in range: %d | paper or no document: %d | "
             "PDF only, no iXBRL: %d | no parseable facts: %d | fetch errors: %d",
             counts["no_accounts"], counts["paper_or_no_doc"], counts["pdf_only"],
             counts["no_facts"], counts["fetch_errors"])
    log.info("balance-sheet-only (filleted, no P&L): %d of %d firm-years (%.0f%%)",
             counts["filleted"], len(rows), 100 * counts["filleted"] / max(len(rows), 1))
    log.info("identity checks: %d ok, %d flagged; %d uncached API calls",
             len(rows) - flagged, flagged, ch.calls)
    if not args.no_wide:
        build_wide(args.long_output, args.wide_output, args.dictionary_output, rows,
                   args.wide_min_share, args.ascii_columns)
    if v2_rows is not None:
        if args.min_v2_fields:
            before = len(v2_rows)
            v2_rows = [r for r in v2_rows if r["fields_found"] >= args.min_v2_fields]
            log.info("Panel V2: kept %d of %d firm-years with >= %d fields present",
                     len(v2_rows), before, args.min_v2_fields)
        write_v2(args.v2_output, args.v2_coverage_output, v2_rows, args.na_value)
    return 0


if __name__ == "__main__":
    sys.exit(main())